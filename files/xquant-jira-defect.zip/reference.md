# Jira 脚本参考

站点默认 `http://jira.xquant.com:8888`（Jira Server 8.17）。可用环境变量 `JIRA_BASE` 覆盖。认证头为 `Authorization: Bearer`，令牌只来自 `JIRA_TOKEN`。

在仓库根目录执行：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File ".cursor/skills/xquant-jira-defect/scripts/jira.ps1" <命令>
```

成功和失败都向标准输出打印一个 JSON 对象，看 `ok`。退出码：`0` 成功，`1` 参数或令牌问题，`2` 接口失败，`3` 流转或屏幕字段对不上。

## 命令

- `myself`：核对当前令牌用户，返回 `name`、`displayName`。
- `search`：分页拉完默认队列。只含 `key`、`priority`、`status`、`summary`。
- `get -Key P008XIR-1`：读标题、描述、评论、附件、`browseUrl`，并解析主需求单号。
- `transitions -Key P008XIR-1`：查看当前可选流转和屏幕字段。
- `assign-dev -Key P008XIR-1`：当前状态为「待开发」时跳过。否则精确点击按钮「分配开发」，填写该按钮打开的表单后提交。
- `comment -Key P008XIR-1 -BodyFile <utf8文本>`：发表评论。
- `resolve -Key P008XIR-1 -NotesFile <utf8.json>`：仅当当前状态为「待开发」。精确点击按钮「解决问题」，不判断点击后的工单状态。表单里「解决结果」选择「已解决」，然后提交。

默认 JQL 写在脚本内：

```text
project = P008XIR AND issuetype = 子缺陷 AND status in (新建, 待开发) AND resolution = Unresolved AND 开发人员★ in (xian.wang) ORDER BY priority DESC, updated DESC
```

覆盖 JQL 用 `-JqlFile`。`-Date`、`-Developer`、`-Estimate`、`-Workload`、`-DocOption` 仅在用户明确要求时覆盖。

`resolve` 的 JSON：

```json
{"cause":"原因分析","solution":"解决方案","testAdvice":"测试建议"}
```

三个字段都必须是非空字符串。

## 主需求单号

`get` 在读子缺陷之后解析唯一的主需求单号，供搜代码和写行注释。子缺陷单号只用于 Jira 的分配开发和已解决。

解析顺序：

1. 在 `/rest/api/2/field` 里找显示名去掉 `★` 后等于「主需求」，或以「主需求」开头的字段，读取子缺陷上这些字段里的单号。
2. 子缺陷上为空、且存在父事项时，再读父事项的同一字段。
3. 站点没有这类字段时，才采用名称里带「主需求」的问题关联，或父事项类型名里带「主需求」的父单号。

恰好一个单号时，`mainRequirement` 含 `key`、`summary`、`issueType`、`source`。没有，或解析出多个不同单号时，`mainRequirement` 为 null，并带上 `mainRequirementError`、`mainRequirementCandidates`、`parent`、`links`。此时停止，不要猜测，也不要用子缺陷单号写注释。

行注释：

```text
// yyyy-MM-dd 姓名 P008XIR-主需求号 改动原因
```

## 屏幕字段

脚本按流转屏幕上的显示名找字段 id，再按字段类型填写。找不到约定字段，或屏幕上还有别的必填字段时，不提交，并返回 `missing`、`unmappedRequired`、`present`、`availableTransitions`。

分配开发：

- 要求开发完成日期★：运行当天，`yyyy-MM-dd`（日期时间类型则补当天 00:00:00）
- 预估开发工作量（人天）：`0`（也接受半角括号）
- 开发人员，或开发人员★：`xian.wang`

解决问题：

- 解决结果：选项「已解决」。不因该按钮跳转到的状态而停止
- 缺陷引入阶段及原因：两个下拉框分别选「编码阶段」和「逻辑问题」。级联字段按父子选项提交；若屏幕拆成「缺陷引入阶段」和「缺陷引入原因」，则分别选择这两项
- 实际开发日期：运行当天
- 实际开发工作量：`0`
- 文档/脚本是否提交：选项「不提交任何内容」
- 开发说明（原因分析）、开发说明（解决方案）：也接受半角括号
- 测试建议

选项按 `allowedValues` 的显示值匹配，提交选项 id。类型不是选项时，才把「不提交任何内容」作为文本提交。

## 确认文案

改完代码、尚未写 Jira 时，用下面的结构问用户，并填入实际内容：

```text
代码已改完，尚未写 Jira。请确认：
- 子缺陷：{key}
- 主需求：{mainRequirement.key}
- 注释单号：{mainRequirement.key}
- 改动：{文件与方法}
- 开发说明（原因分析）：{cause}
- 开发说明（解决方案）：{solution}
- 测试建议：{testAdvice}

回复「确认」后才会依次处理这一条。
当前状态不是待开发时，点击「分配开发」并填写：要求开发完成日期★为今天，预估开发工作量（人天）为 0，开发人员为 xian.wang。已是待开发则跳过。
按你点名时的要求写评论。
然后在待开发状态下点击「解决问题」并填写后提交：解决结果为已解决，缺陷引入阶段及原因的两个下拉框分别为编码阶段和逻辑问题，实际开发日期为今天，实际开发工作量为 0，文档/脚本是否提交为不提交任何内容，以及上面三段说明。不因点击后的工单状态停下。
```

## 失败

- HTTP 401：令牌无效或已过期。
- HTTP 403：没有权限。
- 未找到按钮，或同名按钮多于一个：列出 `availableTransitions` 后停止，不要改点别的按钮。点击「解决问题」后工单变成什么状态，不影响提交。
- 当前状态不是待开发就执行 `resolve`：停止，不要提交。
- 字段或选项对不上：列出屏幕字段和可选值后停止，不要猜测另一个按钮。
- 分配开发失败：不要继续评论和「解决问题」。跳过分配开发不算失败。
