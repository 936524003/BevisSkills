﻿#Requires -Version 5.1
<#
.SYNOPSIS
  调用 xQuant Jira Server REST。令牌只从环境变量 JIRA_TOKEN 读取。
.DESCRIPTION
  由 xquant-jira-defect Skill 执行。不要在参数里传令牌。
#>
[CmdletBinding()]
param(
    [Parameter(Position = 0)]
    [string]$Command,

    [string]$Key,
    [string]$Jql,
    [string]$JqlFile,
    [string]$BodyFile,
    [string]$NotesFile,
    [string]$Date,
    [string]$Developer = "xian.wang",
    [double]$Estimate = 0,
    [double]$Workload = 0,
    [string]$DocOption = "不提交任何内容",
    [int]$PageSize = 50,
    [int]$MaxIssues = 500
)

$ErrorActionPreference = "Stop"

$script:DefaultJql = @'
project = P008XIR AND issuetype = 子缺陷 AND status in (新建, 待开发) AND resolution = Unresolved AND 开发人员★ in (xian.wang) ORDER BY priority DESC, updated DESC
'@.Trim()

$script:AssignDevFields = @(
    @{ Names = @("要求开发完成日期★"); Kind = "date"; ValueKey = "date" }
    @{ Names = @("预估开发工作量（人天）", "预估开发工作量(人天)"); Kind = "number"; ValueKey = "estimate" }
    @{ Names = @("开发人员", "开发人员★"); Kind = "user"; ValueKey = "developer" }
)

$script:ResolveFields = @(
    @{ Names = @("实际开发日期"); Kind = "date"; ValueKey = "date" }
    @{ Names = @("实际开发工作量"); Kind = "number"; ValueKey = "workload" }
    @{ Names = @("文档/脚本是否提交"); Kind = "option"; ValueKey = "docOption" }
    @{ Names = @("开发说明（原因分析）", "开发说明(原因分析)"); Kind = "text"; ValueKey = "cause" }
    @{ Names = @("开发说明（解决方案）", "开发说明(解决方案)"); Kind = "text"; ValueKey = "solution" }
    @{ Names = @("测试建议"); Kind = "text"; ValueKey = "testAdvice" }
    @{ Names = @("解决结果"); Kind = "resolution"; ValueKey = "resolution" }
    @{ Names = @("缺陷引入阶段及原因"); Kind = "intro"; ValueKey = "introCause" }
)

function Write-Result {
    param($Object, [int]$ExitCode = 0)
    $json = ConvertTo-Json -InputObject $Object -Depth 30
    try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch {}
    $script:OutputEncodingBackup = $OutputEncoding
    $OutputEncoding = [System.Text.Encoding]::UTF8
    [Console]::Out.WriteLine($json)
    if ($ExitCode -ne 0) { exit $ExitCode }
}

function Read-Utf8File {
    param([string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) {
        Write-Result @{ ok = $false; error = "文件不存在: $Path" } 1
    }
    $bytes = [System.IO.File]::ReadAllBytes($Path)
    if ($bytes.Length -ge 3 -and $bytes[0] -eq 0xEF -and $bytes[1] -eq 0xBB -and $bytes[2] -eq 0xBF) {
        return [System.Text.Encoding]::UTF8.GetString($bytes, 3, $bytes.Length - 3)
    }
    return [System.Text.Encoding]::UTF8.GetString($bytes)
}

function Get-BaseUrl {
    $raw = $env:JIRA_BASE
    if ([string]::IsNullOrWhiteSpace($raw)) {
        return "http://jira.xquant.com:8888"
    }
    $trimmed = $raw.Trim().TrimEnd("/")
    if ($trimmed -notmatch "^https?://") {
        Write-Result @{ ok = $false; error = "JIRA_BASE 必须以 http:// 或 https:// 开头" } 1
    }
    return $trimmed
}

function New-JiraClient {
    Add-Type -AssemblyName System.Net.Http
    $token = $env:JIRA_TOKEN
    if ([string]::IsNullOrWhiteSpace($token)) {
        Write-Result @{ ok = $false; error = "未设置环境变量 JIRA_TOKEN" } 1
    }
    try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch {}
    $client = New-Object System.Net.Http.HttpClient
    $client.Timeout = [TimeSpan]::FromSeconds(60)
    $client.DefaultRequestHeaders.Authorization = New-Object System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", $token.Trim())
    $client.DefaultRequestHeaders.Accept.Add((New-Object System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json")))
    return $client
}

function Convert-JsonText {
    param([string]$Text)
    if ([string]::IsNullOrWhiteSpace($Text)) { return $null }
    return ($Text | ConvertFrom-Json)
}

function Invoke-JiraApi {
    param(
        [string]$Method,
        [string]$RelativeUrl,
        $BodyObject,
        [hashtable]$Query
    )
    $url = $script:BaseUrl + $RelativeUrl
    if ($Query -and $Query.Count -gt 0) {
        $pairs = @()
        foreach ($name in $Query.Keys) {
            $pairs += ("{0}={1}" -f [uri]::EscapeDataString([string]$name), [uri]::EscapeDataString([string]$Query[$name]))
        }
        $url += "?" + ($pairs -join "&")
    }

    $request = New-Object System.Net.Http.HttpRequestMessage($Method, $url)
    if ($null -ne $BodyObject) {
        $json = ConvertTo-Json -InputObject $BodyObject -Depth 30 -Compress
        $request.Content = New-Object System.Net.Http.StringContent($json, (New-Object System.Text.UTF8Encoding $false), "application/json")
    }

    try {
        $response = $script:Http.SendAsync($request).GetAwaiter().GetResult()
        $raw = $response.Content.ReadAsStringAsync().GetAwaiter().GetResult()
    } catch {
        return @{ ok = $false; status = 0; error = ("无法连接 Jira: " + $_.Exception.Message); data = $null }
    }

    $code = [int]$response.StatusCode
    $data = $null
    if (-not [string]::IsNullOrWhiteSpace($raw)) {
        try { $data = Convert-JsonText $raw } catch { $data = $null }
    }
    if ($code -ge 200 -and $code -lt 300) {
        return @{ ok = $true; status = $code; data = $data; raw = $raw }
    }

    $message = "Jira 返回 HTTP $code"
    if ($code -eq 401) { $message = "令牌无效或已过期" }
    elseif ($code -eq 403) { $message = "没有访问该资源的权限" }
    $detail = $null
    if ($data -and $data.errorMessages) { $detail = @($data.errorMessages) }
    $fieldErrors = $null
    if ($data -and $data.errors) { $fieldErrors = $data.errors }
    return @{ ok = $false; status = $code; error = $message; errorMessages = $detail; errors = $fieldErrors; data = $data }
}

function Assert-IssueKey {
    param([string]$IssueKey)
    if ($IssueKey -notmatch "^[A-Z][A-Z0-9]+-\d+$") {
        Write-Result @{ ok = $false; error = "单号格式不正确: $IssueKey" } 1
    }
}

function Get-PropName {
    param($Object, [string]$Name)
    if ($null -eq $Object) { return $null }
    if ($Object -is [hashtable]) {
        if (-not $Object.ContainsKey($Name)) { return $null }
        return $Object[$Name]
    }
    $prop = $Object.PSObject.Properties[$Name]
    if ($null -eq $prop) { return $null }
    return $prop.Value
}

function Get-SpecItem {
    param($Spec, [string]$Name)
    if ($null -eq $Spec) { return $null }
    if ($Spec -is [hashtable]) {
        if (-not $Spec.ContainsKey($Name)) { return $null }
        return $Spec[$Name]
    }
    return (Get-PropName $Spec $Name)
}

function New-KindSpec {
    param([string]$Kind, $Raw)
    switch ($Kind) {
        "date" { return @{ date = [string]$Raw } }
        "number" { return @{ number = [double]$Raw } }
        "user" { return @{ user = [string]$Raw } }
        "option" { return @{ option = [string]$Raw; text = [string]$Raw } }
        "resolution" { return @{ resolution = [string]$Raw } }
        "text" { return @{ text = [string]$Raw } }
        default { return @{ text = [string]$Raw } }
    }
}

function Find-ScreenField {
    param($Transition, [string[]]$Names)
    if ($null -eq $Transition.fields) { return $null }
    foreach ($prop in @($Transition.fields.PSObject.Properties)) {
        $fieldName = [string]$prop.Value.name
        if ($Names -contains $fieldName) {
            return @{ Id = $prop.Name; Meta = $prop.Value; Name = $fieldName }
        }
    }
    return $null
}

function Get-OptionLabel {
    param($Item)
    $label = [string](Get-PropName $Item "value")
    if ([string]::IsNullOrWhiteSpace($label)) { $label = [string](Get-PropName $Item "name") }
    return $label
}

function Convert-CascadeValue {
    param($Meta, [string]$ParentText, [string]$ChildText)
    $allowed = @()
    if ($Meta.allowedValues) { $allowed = @($Meta.allowedValues) }
    if ($allowed.Count -eq 0) {
        return @{ ok = $true; value = @{ value = $ParentText; child = @{ value = $ChildText } } }
    }
    $parentChoices = @()
    foreach ($parent in $allowed) {
        $parentLabel = Get-OptionLabel $parent
        $parentChoices += $parentLabel
        if ($parentLabel -ne $ParentText) { continue }
        $childSource = Get-PropName $parent "children"
        if ($null -eq $childSource) { $childSource = Get-PropName $parent "child" }
        $children = @()
        if ($childSource) { $children = @($childSource) }
        $parentId = [string](Get-PropName $parent "id")
        if ($children.Count -eq 0) {
            $childValue = @{ value = $ChildText }
            if (-not [string]::IsNullOrWhiteSpace($parentId)) {
                return @{ ok = $true; value = @{ id = $parentId; child = $childValue } }
            }
            return @{ ok = $true; value = @{ value = $ParentText; child = $childValue } }
        }
        $childChoices = @()
        foreach ($child in $children) {
            $childLabel = Get-OptionLabel $child
            $childChoices += $childLabel
            if ($childLabel -ne $ChildText) { continue }
            $childId = [string](Get-PropName $child "id")
            $childValue = @{ value = $ChildText }
            if (-not [string]::IsNullOrWhiteSpace($childId)) { $childValue = @{ id = $childId } }
            if (-not [string]::IsNullOrWhiteSpace($parentId)) {
                return @{ ok = $true; value = @{ id = $parentId; child = $childValue } }
            }
            return @{ ok = $true; value = @{ value = $ParentText; child = $childValue } }
        }
        return @{ ok = $false; error = "选项不存在: $ChildText"; allowedValues = $childChoices }
    }
    return @{ ok = $false; error = "选项不存在: $ParentText"; allowedValues = $parentChoices }
}

function Add-IntroCauseField {
    param($Transition, $Fields, $Used, $Raw)
    $parentText = [string](Get-SpecItem $Raw "parent")
    $childText = [string](Get-SpecItem $Raw "child")
    if ([string]::IsNullOrWhiteSpace($parentText) -or [string]::IsNullOrWhiteSpace($childText)) {
        return @{ ok = $false; missing = "缺陷引入阶段及原因" }
    }
    $cascade = Find-ScreenField $Transition @("缺陷引入阶段及原因")
    if ($null -ne $cascade) {
        $converted = Convert-CascadeValue $cascade.Meta $parentText $childText
        if (-not $converted.ok) { return $converted }
        $Fields[$cascade.Id] = $converted.value
        $Used[$cascade.Id] = $true
        return @{ ok = $true; fieldsSet = @($cascade.Name) }
    }
    $stage = Find-ScreenField $Transition @("缺陷引入阶段")
    $reason = Find-ScreenField $Transition @("缺陷引入原因")
    if ($null -ne $stage -and $null -ne $reason) {
        $stageConverted = Convert-FieldValue $stage.Meta "option" (New-KindSpec "option" $parentText)
        if (-not $stageConverted.ok) { return $stageConverted }
        $reasonConverted = Convert-FieldValue $reason.Meta "option" (New-KindSpec "option" $childText)
        if (-not $reasonConverted.ok) { return $reasonConverted }
        $Fields[$stage.Id] = $stageConverted.value
        $Fields[$reason.Id] = $reasonConverted.value
        $Used[$stage.Id] = $true
        $Used[$reason.Id] = $true
        return @{ ok = $true; fieldsSet = @($stage.Name, $reason.Name) }
    }
    return @{ ok = $false; missing = "缺陷引入阶段及原因" }
}

function Convert-ResolutionValue {
    param($Meta, [string]$ResolutionName)
    $allowed = @()
    if ($Meta.allowedValues) { $allowed = @($Meta.allowedValues) }
    if ($allowed.Count -eq 0) {
        return @{ ok = $true; value = @{ name = $ResolutionName } }
    }
    $choices = @()
    foreach ($item in $allowed) {
        $label = [string](Get-PropName $item "name")
        if ([string]::IsNullOrWhiteSpace($label)) { $label = [string](Get-PropName $item "value") }
        $choices += $label
        if ($label -ne $ResolutionName) { continue }
        $id = [string](Get-PropName $item "id")
        if (-not [string]::IsNullOrWhiteSpace($id)) {
            return @{ ok = $true; value = @{ id = $id } }
        }
        return @{ ok = $true; value = @{ name = $ResolutionName } }
    }
    return @{ ok = $false; error = "选项不存在: $ResolutionName"; allowedValues = $choices }
}

function Convert-OptionValue {
    param($Meta, [string]$OptionText)
    $allowed = @($Meta.allowedValues)
    if ($allowed.Count -eq 0 -or $null -eq $Meta.allowedValues) {
        return @{ ok = $true; value = @{ value = $OptionText } }
    }
    foreach ($item in $allowed) {
        if ([string]$item.value -eq $OptionText) {
            return @{ ok = $true; value = @{ id = [string]$item.id } }
        }
    }
    $choices = @()
    foreach ($item in $allowed) { $choices += [string]$item.value }
    return @{ ok = $false; error = "选项不存在: $OptionText"; allowedValues = $choices }
}

function Convert-FieldValue {
    param($Meta, [string]$Kind, $Spec)
    $type = [string](Get-PropName $Meta.schema "type")
    $items = [string](Get-PropName $Meta.schema "items")

    if ($Kind -eq "resolution" -and ($type -eq "resolution" -or $type -eq "option")) {
        return Convert-ResolutionValue $Meta ([string]$Spec.resolution)
    }

    if ($Kind -eq "option" -and ($type -eq "option" -or ($type -eq "array" -and $items -eq "option"))) {
        $converted = Convert-OptionValue $Meta ([string]$Spec.option)
        if (-not $converted.ok) { return $converted }
        if ($type -eq "array") { return @{ ok = $true; value = @($converted.value) } }
        return $converted
    }

    $text = $null
    $number = $null
    $user = $null
    if ($Kind -eq "date") { $text = [string]$Spec.date }
    elseif ($Kind -eq "number") { $number = [double]$Spec.number; $text = [string]$Spec.number }
    elseif ($Kind -eq "user") { $user = [string]$Spec.user; $text = $user }
    elseif ($Kind -eq "text" -or $Kind -eq "option") { $text = [string]$Spec.text; if ($Kind -eq "option") { $text = [string]$Spec.option } }
    else { return @{ ok = $false; error = "不支持的字段种类: $Kind" } }

    switch ($type) {
        "date" { return @{ ok = $true; value = [string]$Spec.date } }
        "datetime" {
            $parsed = [datetime]::ParseExact([string]$Spec.date, "yyyy-MM-dd", [Globalization.CultureInfo]::InvariantCulture)
            return @{ ok = $true; value = $parsed.ToString("yyyy-MM-dd'T'00:00:00.000zzz") }
        }
        "number" { return @{ ok = $true; value = [double]$number } }
        "string" { return @{ ok = $true; value = $text } }
        "user" { return @{ ok = $true; value = @{ name = $user } } }
        "array" {
            if ($items -eq "user") { return @{ ok = $true; value = @(@{ name = $user }) } }
            if ($items -eq "string") { return @{ ok = $true; value = @($text) } }
            return @{ ok = $false; error = "不支持的数组字段类型: $items" }
        }
        default { return @{ ok = $false; error = "字段类型无法填写: $type" } }
    }
}

function Get-ScreenFields {
    param($Transition)
    $rows = @()
    if ($null -eq $Transition.fields) { return $rows }
    foreach ($prop in @($Transition.fields.PSObject.Properties)) {
        $meta = $prop.Value
        $allowed = @()
        if ($meta.allowedValues) {
            foreach ($item in @($meta.allowedValues)) {
                $label = [string](Get-PropName $item "value")
                if ([string]::IsNullOrWhiteSpace($label)) { $label = [string](Get-PropName $item "name") }
                $allowed += $label
            }
        }
        $rows += @{
            id = $prop.Name
            name = [string]$meta.name
            required = ($meta.required -eq $true)
            type = [string](Get-PropName $meta.schema "type")
            allowedValues = $allowed
        }
    }
    return $rows
}

function Select-Transition {
    param($Transitions, [string]$Mode)
    $buttonName = "分配开发"
    if ($Mode -eq "resolve") { $buttonName = "解决问题" }
    $named = New-Object System.Collections.Generic.List[object]
    $source = @()
    if ($Transitions) { $source = @($Transitions) }
    foreach ($item in $source) {
        if ([string]$item.name -eq $buttonName) { [void]$named.Add($item) }
    }
    return ,$named
}

function Resolve-TransitionRequest {
    param($TransitionsDocument, [string]$Mode, $Spec)
    $transitions = @()
    if ($TransitionsDocument -and $TransitionsDocument.transitions) {
        $transitions = @($TransitionsDocument.transitions)
    }
    $available = @()
    foreach ($item in $transitions) {
        $toName = ""
        if ($item.to) { $toName = [string]$item.to.name }
        $available += @{ id = [string]$item.id; name = [string]$item.name; to = $toName }
    }

    $selected = Select-Transition $transitions $Mode
    $picked = New-Object System.Collections.Generic.List[object]
    if ($null -ne $selected) {
        foreach ($item in $selected) { [void]$picked.Add($item) }
    }
    $label = "分配开发"
    if ($Mode -eq "resolve") { $label = "解决问题" }
    if ($picked.Count -eq 0) {
        return @{ ok = $false; error = "未找到按钮「$label」"; availableTransitions = $available }
    }
    if ($picked.Count -gt 1) {
        return @{ ok = $false; error = "找到多个按钮「$label」"; availableTransitions = $available }
    }

    $transition = $picked[0]
    $definitions = $script:AssignDevFields
    if ($Mode -eq "resolve") { $definitions = $script:ResolveFields }

    $fields = @{}
    $fieldsSet = @()
    $missing = @()
    $used = @{}
    foreach ($definition in $definitions) {
        $raw = Get-SpecItem $Spec $definition.ValueKey
        if ($definition.Kind -eq "intro") {
            $applied = Add-IntroCauseField $transition $fields $used $raw
            if (-not $applied.ok) {
                if ($applied.missing) {
                    $missing += [string]$applied.missing
                    continue
                }
                return @{
                    ok = $false
                    error = ("字段「缺陷引入阶段及原因」{0}" -f $applied.error)
                    allowedValues = $applied.allowedValues
                    present = @(Get-ScreenFields $transition)
                    availableTransitions = $available
                }
            }
            foreach ($appliedName in @($applied.fieldsSet)) { $fieldsSet += $appliedName }
            continue
        }
        $rawMissing = $false
        if ($definition.Kind -eq "number") {
            if ($null -eq $raw) { $rawMissing = $true }
        } elseif ([string]::IsNullOrWhiteSpace([string]$raw)) {
            $rawMissing = $true
        }
        if ($rawMissing) {
            $missing += ($definition.Names -join " / ")
            continue
        }
        $found = Find-ScreenField $transition $definition.Names
        if ($null -eq $found) {
            $missing += ($definition.Names -join " / ")
            continue
        }
        $converted = Convert-FieldValue $found.Meta $definition.Kind (New-KindSpec $definition.Kind $raw)
        if (-not $converted.ok) {
            return @{
                ok = $false
                error = ("字段「{0}」{1}" -f $found.Name, $converted.error)
                allowedValues = $converted.allowedValues
                present = @(Get-ScreenFields $transition)
                availableTransitions = $available
            }
        }
        $fields[$found.Id] = $converted.value
        $fieldsSet += $found.Name
        $used[$found.Id] = $true
    }

    $unmappedRequired = @()
    if ($null -ne $transition.fields) {
        foreach ($prop in @($transition.fields.PSObject.Properties)) {
            if ($prop.Value.required -eq $true -and -not $used.ContainsKey($prop.Name)) {
                $unmappedRequired += [string]$prop.Value.name
            }
        }
    }

    if ($missing.Count -gt 0 -or $unmappedRequired.Count -gt 0) {
        return @{
            ok = $false
            error = "流转屏幕字段无法按约定填写"
            missing = $missing
            unmappedRequired = $unmappedRequired
            present = @(Get-ScreenFields $transition)
            availableTransitions = $available
        }
    }

    $toName = ""
    if ($transition.to) { $toName = [string]$transition.to.name }
    return @{
        ok = $true
        transitionId = [string]$transition.id
        transitionName = [string]$transition.name
        to = $toName
        fields = $fields
        fieldsSet = $fieldsSet
    }
}

function Get-IssueStatusName {
    param([string]$IssueKey)
    $result = Invoke-JiraApi -Method "GET" -RelativeUrl "/rest/api/2/issue/$IssueKey" -Query @{ fields = "status" }
    if (-not $result.ok) { return $result }
    $status = ""
    $statusObj = Get-PropName $result.data.fields "status"
    if ($statusObj) { $status = [string](Get-PropName $statusObj "name") }
    return @{ ok = $true; status = $status }
}

function Invoke-TransitionCommand {
    param([string]$Mode, $Spec)
    Assert-IssueKey $Key
    $loaded = Invoke-JiraApi -Method "GET" -RelativeUrl "/rest/api/2/issue/$Key/transitions" -Query @{ expand = "transitions.fields" }
    if (-not $loaded.ok) { Write-Result $loaded 2 }
    $resolved = Resolve-TransitionRequest $loaded.data $Mode $Spec
    if (-not $resolved.ok) { Write-Result $resolved 3 }
    $body = @{
        transition = @{ id = $resolved.transitionId }
        fields = $resolved.fields
    }
    $posted = Invoke-JiraApi -Method "POST" -RelativeUrl "/rest/api/2/issue/$Key/transitions" -BodyObject $body
    if (-not $posted.ok) { Write-Result $posted 2 }
    Write-Result @{
        ok = $true
        key = $Key
        transitionId = $resolved.transitionId
        transitionName = $resolved.transitionName
        to = $resolved.to
        fieldsSet = $resolved.fieldsSet
    }
}

function Invoke-Myself {
    $result = Invoke-JiraApi -Method "GET" -RelativeUrl "/rest/api/2/myself"
    if (-not $result.ok) { Write-Result $result 2 }
    $data = $result.data
    Write-Result @{
        ok = $true
        name = [string]$data.name
        displayName = [string]$data.displayName
        key = [string]$data.key
    }
}

function Invoke-Search {
    $jqlText = $script:DefaultJql
    if (-not [string]::IsNullOrWhiteSpace($JqlFile)) {
        $jqlText = (Read-Utf8File $JqlFile).Trim()
    } elseif (-not [string]::IsNullOrWhiteSpace($Jql)) {
        $jqlText = $Jql.Trim()
    }
    if ([string]::IsNullOrWhiteSpace($jqlText)) {
        Write-Result @{ ok = $false; error = "JQL 为空" } 1
    }
    if ($PageSize -lt 1 -or $PageSize -gt 100) {
        Write-Result @{ ok = $false; error = "PageSize 必须在 1 到 100 之间" } 1
    }

    $issues = @()
    $startAt = 0
    $total = 0
    do {
        $page = Invoke-JiraApi -Method "GET" -RelativeUrl "/rest/api/2/search" -Query @{
            jql = $jqlText
            startAt = "$startAt"
            maxResults = "$PageSize"
            fields = "summary,status,priority"
        }
        if (-not $page.ok) { Write-Result $page 2 }
        $total = [int]$page.data.total
        $pageIssues = @()
        if ($page.data.issues) { $pageIssues = @($page.data.issues) }
        foreach ($issue in $pageIssues) {
            $priority = ""
            $status = ""
            if ($issue.fields.priority) { $priority = [string]$issue.fields.priority.name }
            if ($issue.fields.status) { $status = [string]$issue.fields.status.name }
            $issues += @{
                key = [string]$issue.key
                priority = $priority
                status = $status
                summary = [string]$issue.fields.summary
            }
        }
        $count = $pageIssues.Count
        if ($count -le 0) { break }
        $startAt += $count
    } while ($startAt -lt $total -and $issues.Count -lt $MaxIssues)

    Write-Result @{
        ok = $true
        total = $total
        returned = $issues.Count
        truncated = ($issues.Count -lt $total)
        issues = $issues
    }
}

function Get-NormalizedFieldName {
    param([string]$Name)
    if ([string]::IsNullOrWhiteSpace($Name)) { return "" }
    return ($Name.Trim() -replace "[★☆*]", "").Trim()
}

function Test-MainRequirementFieldName {
    param([string]$Name)
    $normalized = Get-NormalizedFieldName $Name
    return ($normalized -eq "主需求" -or $normalized.StartsWith("主需求"))
}

function Test-MainRequirementMention {
    param([string]$Name)
    $normalized = Get-NormalizedFieldName $Name
    return $normalized.Contains("主需求")
}

function Add-IssueKeysFromValue {
    param($Value, $Sink)
    if ($null -eq $Value -or $null -eq $Sink) { return }
    if ($Value -is [string]) {
        foreach ($match in [regex]::Matches($Value, "[A-Z][A-Z0-9]+-\d+")) {
            $keyText = $match.Value
            if (-not $Sink.Contains($keyText)) { [void]$Sink.Add($keyText) }
        }
        return
    }
    $keyProp = Get-PropName $Value "key"
    if ($keyProp -is [string] -and $keyProp -match "^[A-Z][A-Z0-9]+-\d+$") {
        if (-not $Sink.Contains($keyProp)) { [void]$Sink.Add($keyProp) }
        return
    }
    $valueProp = Get-PropName $Value "value"
    if ($null -ne $valueProp) { Add-IssueKeysFromValue $valueProp $Sink }
    $isList = $Value -is [System.Collections.IEnumerable] -and -not ($Value -is [pscustomobject])
    if (-not $isList) { return }
    $items = @()
    if ($Value) { $items = @($Value) }
    foreach ($item in $items) { Add-IssueKeysFromValue $item $Sink }
}

function Get-MainKeysOnIssue {
    param($IssueFields, [string[]]$Ids)
    $sink = New-Object System.Collections.Generic.List[string]
    if ($Ids) {
        foreach ($id in @($Ids)) {
            if ([string]::IsNullOrWhiteSpace($id)) { continue }
            Add-IssueKeysFromValue (Get-PropName $IssueFields $id) $sink
        }
    }
    return ,$sink
}

function Get-IssueLinkRows {
    param($IssueFields)
    $rows = New-Object System.Collections.Generic.List[object]
    $links = Get-PropName $IssueFields "issuelinks"
    $linkList = @()
    if ($links) { $linkList = @($links) }
    foreach ($link in $linkList) {
        $typeObj = Get-PropName $link "type"
        $typeName = ""
        $inward = ""
        $outward = ""
        if ($typeObj) {
            $typeName = [string](Get-PropName $typeObj "name")
            $inward = [string](Get-PropName $typeObj "inward")
            $outward = [string](Get-PropName $typeObj "outward")
        }
        $other = Get-PropName $link "outwardIssue"
        $direction = "outward"
        if ($null -eq $other) {
            $other = Get-PropName $link "inwardIssue"
            $direction = "inward"
        }
        if ($null -eq $other) { continue }
        $otherFields = Get-PropName $other "fields"
        $summary = ""
        $issueType = ""
        if ($otherFields) {
            $summary = [string](Get-PropName $otherFields "summary")
            $issueTypeObj = Get-PropName $otherFields "issuetype"
            if ($issueTypeObj) { $issueType = [string](Get-PropName $issueTypeObj "name") }
        }
        $nameBlob = "$typeName $inward $outward $issueType"
        [void]$rows.Add([pscustomobject]@{
            key = [string](Get-PropName $other "key")
            summary = $summary
            issueType = $issueType
            linkType = $typeName
            direction = $direction
            isMainRequirement = [bool](Test-MainRequirementMention $nameBlob)
        })
    }
    return ,$rows
}

function Get-ParentBriefFromFields {
    param($IssueFields)
    $parent = Get-PropName $IssueFields "parent"
    if ($null -eq $parent) { return $null }
    $parentFields = Get-PropName $parent "fields"
    $summary = ""
    $issueType = ""
    if ($parentFields) {
        $summary = [string](Get-PropName $parentFields "summary")
        $issueTypeObj = Get-PropName $parentFields "issuetype"
        if ($issueTypeObj) { $issueType = [string](Get-PropName $issueTypeObj "name") }
    }
    return @{
        key = [string](Get-PropName $parent "key")
        summary = $summary
        issueType = $issueType
    }
}

function Resolve-MainRequirement {
    param(
        [bool]$HasMainField,
        $FieldKeys,
        [string]$FieldSource,
        $Parent,
        $LinkRows
    )
    $distinct = @()
    if ($FieldKeys) {
        foreach ($fieldKey in @($FieldKeys)) {
            if ($fieldKey -and $distinct -notcontains $fieldKey) { $distinct += $fieldKey }
        }
    }
    if ($HasMainField) {
        if ($distinct.Count -eq 1) {
            return @{ ok = $true; key = $distinct[0]; source = $FieldSource; candidates = @(); error = $null }
        }
        if ($distinct.Count -eq 0) {
            return @{ ok = $false; key = $null; source = $FieldSource; candidates = @(); error = "主需求字段为空" }
        }
        return @{ ok = $false; key = $null; source = $FieldSource; candidates = $distinct; error = "主需求字段含有多个单号" }
    }

    $candidates = @()
    $linkList = New-Object System.Collections.Generic.List[object]
    if ($null -ne $LinkRows) {
        $singleRow = ($LinkRows -is [hashtable]) -or (($LinkRows.PSObject.TypeNames -contains "System.Management.Automation.PSCustomObject") -and -not ($LinkRows -is [System.Collections.IEnumerable]))
        if ($singleRow) {
            [void]$linkList.Add($LinkRows)
        } else {
            foreach ($row in $LinkRows) { [void]$linkList.Add($row) }
        }
    }
    foreach ($row in $linkList) {
        $flag = Get-SpecItem $row "isMainRequirement"
        if (-not $flag) { continue }
        $linkKey = [string](Get-SpecItem $row "key")
        if ($linkKey -and $candidates -notcontains $linkKey) { $candidates += $linkKey }
    }
    $parentKey = ""
    $parentType = ""
    if ($Parent) {
        $parentKey = [string](Get-SpecItem $Parent "key")
        $parentType = [string](Get-SpecItem $Parent "issueType")
    }
    $parentIsMain = (Test-MainRequirementMention $parentType)
    if ($parentIsMain -and $parentKey -and $candidates -notcontains $parentKey) { $candidates += $parentKey }
    if ($candidates.Count -eq 1) {
        $source = "关联"
        if ($parentIsMain -and $candidates[0] -eq $parentKey) { $source = "父事项" }
        return @{ ok = $true; key = $candidates[0]; source = $source; candidates = @(); error = $null }
    }
    if ($candidates.Count -gt 1) {
        return @{ ok = $false; key = $null; source = $null; candidates = $candidates; error = "找到多个主需求单号" }
    }
    return @{ ok = $false; key = $null; source = $null; candidates = @(); error = "未找到主需求单号" }
}

function Get-MainRequirementCatalog {
    $result = Invoke-JiraApi -Method "GET" -RelativeUrl "/rest/api/2/field"
    if (-not $result.ok) { return $result }
    $ids = @()
    $names = @()
    $fieldList = @()
    if ($result.data) { $fieldList = @($result.data) }
    foreach ($field in $fieldList) {
        $name = [string](Get-PropName $field "name")
        if (-not (Test-MainRequirementFieldName $name)) { continue }
        $id = [string](Get-PropName $field "id")
        if ($id -and $ids -notcontains $id) {
            $ids += $id
            $names += $name
        }
    }
    return @{ ok = $true; ids = $ids; names = $names }
}

function Get-IssueBrief {
    param([string]$IssueKey)
    $result = Invoke-JiraApi -Method "GET" -RelativeUrl "/rest/api/2/issue/$IssueKey" -Query @{
        fields = "summary,issuetype,status"
    }
    if (-not $result.ok) {
        return @{ key = $IssueKey; summary = ""; issueType = ""; status = ""; fetchError = [string]$result.error }
    }
    $fields = $result.data.fields
    $issueType = ""
    $status = ""
    $typeObj = Get-PropName $fields "issuetype"
    $statusObj = Get-PropName $fields "status"
    if ($typeObj) { $issueType = [string](Get-PropName $typeObj "name") }
    if ($statusObj) { $status = [string](Get-PropName $statusObj "name") }
    return @{
        key = $IssueKey
        summary = [string](Get-PropName $fields "summary")
        issueType = $issueType
        status = $status
        fetchError = $null
    }
}

function Invoke-GetIssue {
    Assert-IssueKey $Key
    $catalog = Get-MainRequirementCatalog
    if (-not $catalog.ok) { Write-Result $catalog 2 }
    $fieldIds = @("summary", "description", "comment", "attachment", "status", "priority", "issuetype", "parent", "issuelinks")
    if ($catalog.ids) {
        foreach ($id in @($catalog.ids)) {
            if ($fieldIds -notcontains $id) { $fieldIds += $id }
        }
    }
    $result = Invoke-JiraApi -Method "GET" -RelativeUrl "/rest/api/2/issue/$Key" -Query @{
        fields = ($fieldIds -join ",")
    }
    if (-not $result.ok) { Write-Result $result 2 }
    $issue = $result.data
    $comments = @()
    if ($issue.fields.comment -and $issue.fields.comment.comments) {
        foreach ($comment in @($issue.fields.comment.comments)) {
            $author = ""
            if ($comment.author) { $author = [string]$comment.author.displayName }
            $comments += @{ author = $author; created = [string]$comment.created; body = [string]$comment.body }
        }
    }
    $attachments = @()
    if ($issue.fields.attachment) {
        foreach ($attachment in @($issue.fields.attachment)) {
            $attachments += @{
                filename = [string]$attachment.filename
                mimeType = [string]$attachment.mimeType
                size = $attachment.size
                content = [string]$attachment.content
            }
        }
    }
    $priority = ""
    $status = ""
    $issueType = ""
    if ($issue.fields.priority) { $priority = [string]$issue.fields.priority.name }
    if ($issue.fields.status) { $status = [string]$issue.fields.status.name }
    if ($issue.fields.issuetype) { $issueType = [string]$issue.fields.issuetype.name }

    $hasMainField = $false
    $catalogIds = @()
    if ($catalog.ids) { $catalogIds = @($catalog.ids); $hasMainField = ($catalogIds.Count -gt 0) }
    $fieldSource = ""
    if ($catalog.names) { $fieldSource = "字段 " + (@($catalog.names) -join "、") }
    $fieldKeys = Get-MainKeysOnIssue $issue.fields $catalogIds
    $parentBrief = Get-ParentBriefFromFields $issue.fields
    $linkRows = Get-IssueLinkRows $issue.fields
    if ($hasMainField -and $fieldKeys.Count -eq 0 -and $parentBrief -and $parentBrief.key) {
        $parentResult = Invoke-JiraApi -Method "GET" -RelativeUrl ("/rest/api/2/issue/" + $parentBrief.key) -Query @{
            fields = (($catalogIds + @("issuelinks")) -join ",")
        }
        if ($parentResult.ok) {
            $parentKeys = Get-MainKeysOnIssue $parentResult.data.fields $catalogIds
            if ($parentKeys.Count -gt 0) {
                $fieldKeys = $parentKeys
                $fieldSource = "父事项 " + $parentBrief.key + " 的" + $fieldSource
            }
            foreach ($parentLink in (Get-IssueLinkRows $parentResult.data.fields)) { [void]$linkRows.Add($parentLink) }
        }
    } elseif (-not $hasMainField -and $parentBrief -and $parentBrief.key) {
        $parentResult = Invoke-JiraApi -Method "GET" -RelativeUrl ("/rest/api/2/issue/" + $parentBrief.key) -Query @{
            fields = "issuelinks"
        }
        if ($parentResult.ok) {
            foreach ($parentLink in (Get-IssueLinkRows $parentResult.data.fields)) { [void]$linkRows.Add($parentLink) }
        }
    }

    $resolvedMain = Resolve-MainRequirement -HasMainField $hasMainField -FieldKeys $fieldKeys -FieldSource $fieldSource -Parent $parentBrief -LinkRows $linkRows
    $mainRequirement = $null
    if ($resolvedMain.ok) {
        $brief = Get-IssueBrief $resolvedMain.key
        $mainRequirement = @{
            key = [string]$brief.key
            summary = [string]$brief.summary
            issueType = [string]$brief.issueType
            status = [string]$brief.status
            source = [string]$resolvedMain.source
            fetchError = $brief.fetchError
        }
    }
    $candidateKeys = @()
    if ($resolvedMain.candidates) { $candidateKeys = @($resolvedMain.candidates) }

    Write-Result @{
        ok = $true
        key = [string]$issue.key
        summary = [string]$issue.fields.summary
        description = [string]$issue.fields.description
        status = $status
        priority = $priority
        issueType = $issueType
        browseUrl = ($script:BaseUrl + "/browse/" + $issue.key)
        comments = $comments
        attachments = $attachments
        parent = $parentBrief
        links = $linkRows
        mainRequirement = $mainRequirement
        mainRequirementError = $resolvedMain.error
        mainRequirementCandidates = $candidateKeys
    }
}

function Invoke-Comment {
    Assert-IssueKey $Key
    if ([string]::IsNullOrWhiteSpace($BodyFile)) {
        Write-Result @{ ok = $false; error = "评论必须通过 -BodyFile 传入 UTF-8 文件" } 1
    }
    $body = (Read-Utf8File $BodyFile).Trim()
    if ([string]::IsNullOrWhiteSpace($body)) {
        Write-Result @{ ok = $false; error = "评论内容为空" } 1
    }
    $result = Invoke-JiraApi -Method "POST" -RelativeUrl "/rest/api/2/issue/$Key/comment" -BodyObject @{ body = $body }
    if (-not $result.ok) { Write-Result $result 2 }
    $commentId = ""
    if ($result.data) { $commentId = [string]$result.data.id }
    Write-Result @{ ok = $true; key = $Key; commentId = $commentId }
}

function Invoke-Transitions {
    Assert-IssueKey $Key
    $result = Invoke-JiraApi -Method "GET" -RelativeUrl "/rest/api/2/issue/$Key/transitions" -Query @{ expand = "transitions.fields" }
    if (-not $result.ok) { Write-Result $result 2 }
    $rows = @()
    $transitionList = @()
    if ($result.data.transitions) { $transitionList = @($result.data.transitions) }
    foreach ($item in $transitionList) {
        $toName = ""
        if ($item.to) { $toName = [string]$item.to.name }
        $rows += @{
            id = [string]$item.id
            name = [string]$item.name
            to = $toName
            fields = @(Get-ScreenFields $item)
        }
    }
    Write-Result @{ ok = $true; key = $Key; transitions = $rows }
}

function Read-NotesFile {
    if ([string]::IsNullOrWhiteSpace($NotesFile)) {
        Write-Result @{ ok = $false; error = "已解决说明必须通过 -NotesFile 传入 UTF-8 JSON" } 1
    }
    $text = Read-Utf8File $NotesFile
    try { $notes = Convert-JsonText $text } catch {
        Write-Result @{ ok = $false; error = "NotesFile 不是合法 JSON" } 1
    }
    $cause = [string]$notes.cause
    $solution = [string]$notes.solution
    $testAdvice = [string]$notes.testAdvice
    if ([string]::IsNullOrWhiteSpace($cause) -or [string]::IsNullOrWhiteSpace($solution) -or [string]::IsNullOrWhiteSpace($testAdvice)) {
        Write-Result @{ ok = $false; error = "NotesFile 必须包含非空的 cause、solution、testAdvice" } 1
    }
    return @{ cause = $cause.Trim(); solution = $solution.Trim(); testAdvice = $testAdvice.Trim() }
}

function Invoke-Main {
    $known = @("myself", "search", "get", "comment", "transitions", "assign-dev", "resolve")
    if ([string]::IsNullOrWhiteSpace($Command) -or $known -notcontains $Command) {
        Write-Result @{ ok = $false; error = "缺少或未知命令。可用: myself, search, get, comment, transitions, assign-dev, resolve" } 1
    }
    $needsKey = @("get", "comment", "transitions", "assign-dev", "resolve")
    if ($needsKey -contains $Command) { Assert-IssueKey $Key }
    $script:BaseUrl = Get-BaseUrl
    $script:Http = New-JiraClient
    try {
        switch ($Command) {
            "myself" { Invoke-Myself }
            "search" { Invoke-Search }
            "get" { Invoke-GetIssue }
            "comment" { Invoke-Comment }
            "transitions" { Invoke-Transitions }
            "assign-dev" {
                $statusResult = Get-IssueStatusName $Key
                if (-not $statusResult.ok) { Write-Result $statusResult 2 }
                if ($statusResult.status -eq "待开发") {
                    Write-Result @{
                        ok = $true
                        key = $Key
                        skipped = $true
                        status = $statusResult.status
                        reason = "当前已是待开发，跳过分配开发"
                    }
                    return
                }
                if ([string]::IsNullOrWhiteSpace($Date)) { $Date = Get-Date -Format "yyyy-MM-dd" }
                Invoke-TransitionCommand "assign-dev" @{
                    date = $Date
                    estimate = $Estimate
                    developer = $Developer
                }
            }
            "resolve" {
                $statusResult = Get-IssueStatusName $Key
                if (-not $statusResult.ok) { Write-Result $statusResult 2 }
                if ($statusResult.status -ne "待开发") {
                    Write-Result @{
                        ok = $false
                        error = "当前状态不是待开发，不能点击「解决问题」"
                        status = $statusResult.status
                    } 3
                    return
                }
                if ([string]::IsNullOrWhiteSpace($Date)) { $Date = Get-Date -Format "yyyy-MM-dd" }
                $notes = Read-NotesFile
                Invoke-TransitionCommand "resolve" @{
                    date = $Date
                    workload = $Workload
                    docOption = $DocOption
                    cause = $notes.cause
                    solution = $notes.solution
                    testAdvice = $notes.testAdvice
                    resolution = "已解决"
                    introCause = @{ parent = "编码阶段"; child = "逻辑问题" }
                }
            }
            default { Write-Result @{ ok = $false; error = "未知命令: $Command" } 1 }
        }
    } finally {
        if ($script:Http) { $script:Http.Dispose() }
    }
}

if ($MyInvocation.InvocationName -ne ".") {
    Invoke-Main
}
