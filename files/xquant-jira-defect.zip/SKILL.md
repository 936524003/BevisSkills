---
name: xquant-jira-defect
description: Lists Hengtai xQuant Jira Server sub-defects for P008XIR, resolves the selected defect to its 主需求 key, analyzes that requirement in the local xIR codebase, and after the user confirms the code change assigns development and resolves the issue. Use when the user asks to 处理 Jira 缺陷, 子缺陷, 主需求, 分配开发, 已解决, jira.xquant.com, or P008XIR defects.
---

# xQuant Jira 子缺陷

处理 `http://jira.xquant.com:8888` 上的子缺陷。先列出队列，用户选定一条后再分析并改代码；用户确认代码之后才写 Jira。

接口细节、字段和失败时怎么停，见 [reference.md](reference.md)。Jira 调用只走 `scripts/jira.ps1`，不要自己拼 REST。

## 阶段

一次只处于一个阶段。没有用户的下一步指示，不得进入后一阶段。

1. **列表**：核对令牌。`myself` 成功后立刻拉取全部缺陷，只展示单号、优先级、状态、标题，然后停下。中间不要等用户确认身份。
2. **改代码**：用户只点名一条之后，才读详情、看图、搜代码并修改。改完展示说明草稿，再停下。
3. **写 Jira**：用户明确确认代码可以之后，才按界面按钮处理这一条：不是待开发时先点「分配开发」并填表；已是待开发则跳过。然后按需要写评论，再点「解决问题」填表提交。

用户一次点名多条单号：不分析、不改代码、不写 Jira，请其改成一条。列表展示里出现的单号不算用户点名。

## 登录

个人访问令牌在 `http://jira.xquant.com:8888/secure/ViewProfile.jspa` 创建。

- 未设置 `JIRA_TOKEN` 时，向用户要令牌，然后停止等待。
- 拿到后只写入当前 shell 的 `$env:JIRA_TOKEN`。不要在回复、参数、仓库、Skill 目录或任何文件中出现令牌。
- 执行 `myself`。失败则停下，说明令牌无效，或管理员可能关闭了个人访问令牌。
- 成功后在同一轮展示 `displayName` 和 `name`，并立刻执行下面的列表拉取。不要停下来请用户核对身份。

## 1. 只列列表

不要传 `-Jql`，使用脚本内置默认 JQL。用户另给 JQL 时，把 JQL 写成临时 UTF-8 文件，用 `-JqlFile` 传入，用完删除。

执行 `search`。`truncated` 为 true 时告诉用户只拉到了上限，不要假装已经全量。`total` 为 0 时停下。

按返回顺序展示，例如：

```text
共 N 条。回复一条单号后才会分析。
1. P008XIR-1 | 紧急 | 新建 | 标题
```

此阶段禁止 `get`、禁止打开浏览器、禁止搜索仓库、禁止改代码、禁止任何写 Jira 的命令。

脚本 JSON 里的中文可能是 `\u` 转义。展示给用户时还原成中文。

## 2. 选定一条后分析并改代码

1. `get` 这一条。描述或评论依赖截图，或附件是图片时，再用 Cursor 内置浏览器打开返回的 `browseUrl` 看图。
2. 使用返回的 `mainRequirement.key` 作为主需求单号。`mainRequirement` 为空，或 `mainRequirementCandidates` 多于一个时，停下并说明 `mainRequirementError`、父事项和关联，不分析、不改代码、不写 Jira。不要改用子缺陷单号充当主需求。
3. 改代码前先读 [../xir-dev-standards/SKILL.md](../xir-dev-standards/SKILL.md)，并按改动层阅读它指向的参考。
4. 先用主需求单号在本仓库搜索已有实现和历史注释，再结合这条子缺陷的描述定位本次修改点。定位不到业务代码就停下，列出查过的路径，不改代码、不写 Jira。
5. 只改这一条。行注释使用 `// yyyy-MM-dd 姓名 {主需求单号} 改动原因`，单号必须是 `mainRequirement.key`。姓名用 `myself` 的 `displayName`。不要把子缺陷单号写进代码注释。不要提交 git。
6. 改完后停下，按 [reference.md](reference.md) 的确认文案展示实际改动，以及原因分析、解决方案、测试建议。三段说明按真实改动用中文写，不照抄 Jira 标题。

未确认前禁止 `assign-dev`、`comment`、`resolve`。

## 3. 确认后写 Jira

只有用户明确确认代码可以（例如「确认」「可以写 Jira」）才继续。用户改了三段说明时，以用户改后的文字为准。代码没有改成功则不写 Jira。

只处理这一条，顺序固定：

1. `assign-dev`。当前状态已是「待开发」时，脚本会跳过并返回 `skipped: true`，不要再点别的按钮补做这一步。其他状态才点击界面按钮「分配开发」，填写表单后提交。不要传日期和人员，除非用户要求覆盖。默认要求开发完成日期★为脚本运行当天，预估开发工作量（人天）为 0，开发人员为 `xian.wang`。
2. 用户点名时说了要写回评论，才把修复意见写入临时 UTF-8 文件并执行 `comment -BodyFile`。没说就不写。用完删除临时文件。
3. `resolve` 只在当前状态为「待开发」时执行：点击界面按钮「解决问题」，在「解决结果」里选择「已解决」，在「缺陷引入阶段及原因」的两个下拉框里分别选择「编码阶段」和「逻辑问题」，再填写其余表单后提交。不要因为点击后的工单状态停下，也不要改点名称是「已解决」的其他按钮。把确认后的三段说明写成临时 UTF-8 JSON（`cause`、`solution`、`testAdvice`），执行 `resolve -NotesFile`。默认实际开发日期为当天，实际开发工作量为 0，文档/脚本是否提交为「不提交任何内容」。用完删除临时文件。不要另外传入引入阶段或原因。

`assign-dev` 失败则停止，不写评论，也不 `resolve`。`skipped: true` 视为这一步已完成，可以继续。任一命令返回 `ok: false` 时，把 `error`、当前状态、可选按钮、缺少字段和未映射的必填字段告诉用户，然后停下，不要改用别的按钮或别的字段值。
