# 命名 / using / 布局 / 注释

源页面：[代码规范](http://172.19.6.53:7777/代码规范/)

完整样式规则见 Wiki「代码分析样式规则」；本文件只收录必须执行的约定。

## 命名法

Pascal：每个单词首字母大写，无分隔符，如 `FirstName`。

Camel：首单词小写，后续单词首字母大写，如 `firstName`。

### 对照

| 对象 | 规则 | 示例 |
|---|---|---|
| 命名空间 | Pascal；顶级可例外（`xQuant`） | `namespace Microsoft.Extensions.Logging` / `namespace xQuant.Log;` |
| 接口 | `I` + Pascal | `ILoggerFactory` |
| 类、结构、记录 | Pascal | `Logger` / `EventId` / `LogEvent` |
| 枚举、枚举值 | Pascal | `LogLevel.Trace` |
| 委托 | Pascal | `LoggedEventHandler` |
| 常量 | Pascal | `DefaultCategoryName` |
| 非私有静态字段 | Pascal | `public static string DefaultCategoryName;` |
| 私有静态字段 | `s_` + Camel | `private static string s_categoryName;` |
| 实例字段 | `_` + Camel | `private string _categoryName;` |
| 属性、事件、方法 | Pascal | `Provider` / `Logged` / `Log()` |
| 参数、局部变量 | Camel | `void Log(LogLevel logLevel, string message)` |

```csharp
public void Log(LogLevel logLevel, string message)
{
    ILoggerProvider provider = this.ILoggerProvider;
    // ...
}
```

### 其他命名

- 集合变量用复数，尽量不要以 `List` 或 `Array` 结尾。
- 取表数据：Biz 以 `Get` 开头，Dal 以 `Query` 开头，如 `GetTrades` / `QueryTrades`。
- 单行不要过长。

## using

- `System*` 排第一。
- 删除不需要的 using。
- 提交前执行「删除 Using 和对齐排序」。
- 尽量简化代码中的命名空间引用，让文件头能看出依赖。

```csharp
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using Microsoft.Practices.EnterpriseLibrary.Data;
using xQuant.BizCore;
```

## 布局

- 缩进统一 4 个空格。
- 每个大括号独占一行，禁止省略。

反例：

```csharp
if (...)
    return 1;
```

正例：块结束的 `}` 后空一行；连续 `}` 之间不空行。

```csharp
if (...)
{
    // ...
}

// 注意我上面空一行
```

## 注释

- 公开成员必须 `///`，说明模块和作用；`<remarks>` 写需求来源（JIRA 编号）。
- 注释符合逻辑，不为注释而注释。
- 及时删除无用注释和被注释掉的代码。
- 注释前空一行。

```csharp
List<string> dates = new List<string>();

// 我是注释，上面有空行
dates.Add(setDate);
```

### `///` 与 `//`

- 一般只在 summary 用 `///`；其余用 `//`。
- `//` 后空一格：`// 我前面有一个空格`
- 不建议 `/* */`，多行用连续 `//`。

### xIR 行注释

格式：

```csharp
// yyyy-MM-dd 开发人员 P008XIR-XXXXX 注释内容
```

```csharp
// 2020-01-04 张三 P008XIR-18713 xIR产品-清算优化-支持清算上下文
```

JIRA 维护信息放 `<remarks>`；`<summary>` 只保留对该成员简明描述。

```csharp
/// <summary>
/// 券余额表关联内部证券账户表条件语句
/// </summary>
/// <param name="filedName">字段名称</param>
/// <param name="cashAccId">内部资金账户</param>
/// <returns>Where子语句</returns>
/// <remarks>2020-11-03 张三 P008XIR-18885 xIR产品-清算优化-持仓余额表Where子语句优化</remarks>
private string BalanceSecuWhereSQLForCashAccount(string filedName, string cashAccId)
{
    return $" EXISTS (SELECT 1 FROM TTRD_ACC_SECU SECU WHERE SECU.ACCID = {filedName} AND SECU.CASH_ACCID = '{cashAccId}') ";
}
```

行注释中 JIRA 号后面必须写改动原因，不要照搬 JIRA 标题。合格 / 不合格对照见 [code-quality-patterns.md](code-quality-patterns.md)。
