# 代码评审清单

源页面：

- [代码评审清单](http://172.19.6.53:7777/代码规范/代码评审清单.html)
- [代码评审规范指导手册](http://172.19.6.53:7777/代码规范/代码评审规范指导手册.html)（评审目的与通用检查维度；具体坑以本清单为准）

评审前：代码已能构建、功能已由开发/质量验证。评审盯一致性、风格、安全、冗余、是否按设计实现。风格细节见 [naming-style.md](naming-style.md)，反例见 [code-quality-patterns.md](code-quality-patterns.md)。

## 公共

### 多线程异常

- APM：不调 `EndInvoke` 则无法捕获异常、资源不能及时释放。
- TAP：.NET Framework 4.0 不捕获会崩溃；4.5+ 默认不崩溃，仍应捕获。
- 显式 `Thread` / `ThreadPool` 必须 `catch`，否则崩溃。

### IDisposable

- 用 `using`；特殊场景用 `try` / `finally`。
- 及时释放 `DbCommand`、`DataReader`。
- 事务及时释放，防止锁表。
- 成员实现了 `IDisposable` 时，类型自身也应实现 `IDisposable`。`ShowDialog` 打开的窗口必须释放。

### 循环体

- 是否有远程调用、数据库调用、其他 I/O。
- 是否在循环中读 `SystemParamConfiguration`（多数查询 O(N)，性能敏感场景禁止反复读；多次访问应先存局部变量）。
- 是否反复读 `GridView.RowCount`（内部会计算；性能敏感场景先存局部变量）。
- 表格绑定列事件、自定义显示事件中禁止耗时操作（含远程调用）。

### 递归 / 异常 / 缓存 / 线程安全

- 递归须有可靠退出条件，考虑脏数据，避免栈溢出。
- 重抛用 `throw;`，禁止 `throw ex;`。中间件抛出的异常若未特殊处理不会记日志，须把原始堆栈记日志。
- 缓存穿透：循环和表格绑定列事件中避免反复查不存在的值；交易对手等场景可用「大于 0」过滤无效数据。
- 多线程写同一字典用 `ConcurrentDictionary`；优先 `System.Collections.Concurrent`。静态方法须线程安全。
- `Dictionary<,>` 用 `TryGetValue`，不要 `ContainsKey` 后再 `[key]`。

### 第三方组件与发布

- 引入第三方组件先通知架构组，评审通过后才能用；使用范围可控，新用到未评估过的功能要再评。
- 框架代码边界见 [framework-guard.md](framework-guard.md)。

### 增量发布陷阱（截至 2024-01-25：有文件修改才更新对应程序集）

调用方项目若无其它改动，增量发布可能不更新其程序集：

- 给参数加默认值 → 调用方仍按旧签名传参，默认值未生效。
- 改参数类型（旧实参仍能隐式转换）→ 运行时因签名变化找不到方法。
- 方法改成泛型（原调用仍满足约束）→ 同上，运行时找不到方法。

涉及签名变更时，必须同步改到所有调用方并确保对应项目会随增量发布更新。

### 其他公共项

- 远程参数避免 `DataTable`，用已声明对象；必须用则设 `RemoteFormat = Binary`。新增远程接口禁止 `DataTable`，见 [grpc-dto.md](grpc-dto.md)。
- 关键节点记日志（如接口交互处）。
- 禁止为迁就局部需求破坏设计（例如仅为界面勾选给 `XPOTCTrade` 加 `Selected`）。
- 方法参数要校验；数组边界；使用前初始化。
- 捕获异常后必须处理（至少记日志）；错误路径也要释放资源。

## DAL

- SQL 参数化。
- 合理选择 `IN` / `EXISTS`；`IN` 用 `SqlWhereHelper`。
- SQL 中 `<>` 不走索引，推荐 `a <> 0` 改为 `(a > 0 OR a < 0)`。
- `UNION ALL` 过多会解析缓慢甚至卡死，评估合理性。
- 债券表、交易表、指令表：禁止随意关联；禁止随意加字段（加字段须架构组批准）。
- 禁止把拼接好的字符串当参数传到下层做 SQL，见 [code-quality-patterns.md](code-quality-patterns.md) 场景七。

## Biz

- 业务流程中的静态字段可能线程不安全。
- Remoting 注册的 Manager 是单例：不要设计实例字段（服务无状态）；必须用则保证线程安全。
- 远程方法尽量不用 `ref` / `out`（RPC 通常不支持，影响拆分和升级）。

## 客户端

- 新增控件加入 `Parent.Controls`。表格 `RepositoryItem` 加到表格以便随表格释放。动态移除控件要 `Dispose`。
- `ShowDialog` 用 `using`；模态关闭不会自动释放，须显式 `Dispose`。
- XPO 对象注意解绑事件（如 `XPRefresh`、`XPOtcTrade`）。动态 `Timer` 也要解绑。
- 禁止在非 UI 线程弹窗或创建控件。非 UI 线程尽量 `BeginInvoke`；`Invoke` 前检查句柄是否已创建、控件是否已释放。
- 消息框必须委托到主线程，可用 `XirHelper.ShowBoxInfoAsync` 等。
- 轮询查询要考虑用户手动查询，可丢弃较早返回的结果。
- GridView 助手类只在界面初始化时通过父类 `BindAssistToGrid` 绑一次，不要重复绑。
- 大量动态控件：初始化前 `SuspendLayout` / `BeginInit`（或 `BeginUpdate`），完成后成对 `EndInit` / `EndUpdate` / `ResumeLayout`。

```csharp
using (Form frm = new Form1())
{
}

public static void LoadCmb(CheckedComboBoxEdit edt, Dictionary<string, string> dic)
{
    edt.Properties.BeginUpdate();
    edt.Properties.Items.BeginUpdate();
    try
    {
    }
    finally
    {
        edt.Properties.Items.EndUpdate();
        edt.Properties.EndUpdate();
    }
}
```

- 界面表格选择列可用 `HashSet<>`。

## 信创后

细则见 [xinchuang-client.md](xinchuang-client.md)。评审时至少核对：

- 客户端（.NET Framework 4.8）禁止直接引用中间件，中间件禁止引用客户端；检查项目文件和命名空间。
- `XXXManager` 用 `XServiceContainer.GetService()`；注入用 `TryAddXXX`。
- 避免析构函数；必须用则 `try/catch`（析构里抛异常会崩溃）。
- 禁止 `Delegate.BeginInvoke` / `EndInvoke`，用 `Task.Run`。
- 路径 `Path.Combine`；换行 `Environment.NewLine`；解析文件时区分来源系统的换行。
