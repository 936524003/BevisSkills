---
name: xir-dev-standards
description: Applies Hengtai xIR/xQuant C# development standards when writing, modifying, or reviewing code. Use when working on xIR, xQuant, 代码规范, 信创, gRPC, DTO, SQL, 代码评审, or WinForms client/middleware changes.
---

# xIR 开发规范

编写、修改或评审本仓库 xIR / xQuant C# 代码时必须套用本 Skill。规范原文见内网 Wiki：[xIR-Wiki](http://172.19.6.53:7777/)。

完整 `.editorconfig`、代码分析器原理、培训计划、COM 更新、Wiki「其他 / dotnet」栏（连接串、MSBuild、NuGet）不在本 Skill 范围。

## 工作流

1. 先对照下方硬规则；与分层、远程、信创冲突时以硬规则为准。
2. 按任务再读对应参考，不要一次读完全部：
   - 命名 / using / 大括号 / 注释 → [naming-style.md](naming-style.md)
   - 代码评审、增量发布 → [review-checklist.md](review-checklist.md)
   - 风格反例、注释写法、可执行杂谈 → [code-quality-patterns.md](code-quality-patterns.md)
   - 远程接口、Dto、深拷贝 → [grpc-dto.md](grpc-dto.md)
   - WinForms、客户端与中间件隔离、路径/换行 → [xinchuang-client.md](xinchuang-client.md)
   - `xQuant.Common`、`SqlWhereHelper`、XPO 缓存等框架代码 → [framework-guard.md](framework-guard.md)
3. 改框架代码先读 `framework-guard.md`；改远程接口先读 `grpc-dto.md`；改 WinForms 先读 `xinchuang-client.md`。
4. 评审时按 `review-checklist.md` 分层过一遍，发现问题按本规范指出，不要改写成通用 C# 教程。

## 硬规则

### 命名

- Pascal：命名空间（顶级可例外如 `xQuant`）、接口（`I` 前缀）、类/结构/记录、枚举及枚举值、委托、常量、非私有静态字段、属性、事件、方法。
- Camel：参数、局部变量。
- 私有静态字段：`s_` + Camel（如 `s_categoryName`）。
- 实例字段：`_` + Camel（如 `_categoryName`）。
- 集合变量用复数，避免以 `List` / `Array` 结尾。
- 取表数据：Biz `Get*`，Dal `Query*`（如 `GetTrades` / `QueryTrades`）。

### 布局

- 缩进 4 空格。
- 大括号独占一行，禁止省略（`if` / `for` 单行也不省）。
- 代码块结束的 `}` 后空一行；连续 `}` 之间不空行。
- 提交前删除无用 using，并执行「删除 Using 和对齐排序」；`System*` 排最前。

### 注释

- 公开成员必须 `///`，说明模块与作用；`<remarks>` 写需求来源（JIRA 号），`<summary>` 只写成员本身。
- 行注释：`// yyyy-MM-dd 姓名 P008XIR-XXXXX 改动原因`。说明这次改了什么、为何这样写，不要照搬 JIRA 标题。
- `//` 后空一格；注释前空一行；不用 `/* */`；删掉无用注释和被注释掉的代码。

### 质量

- 显式 `Thread` / `ThreadPool` 必须 `catch`，否则会崩溃。
- `IDisposable` 用 `using`；及时释放 `DbCommand`、`DataReader`、事务。
- SQL 必须参数化；`IN` 用 `SqlWhereHelper.SplitWhereInCondition`。
- 禁止把拼接好的 SQL 字符串当参数传到下层再查库。
- 重抛用 `throw;`，禁止 `throw ex;`（保留堆栈）。
- 循环内检查远程 / 数据库 / 其他 IO；递归必须有退出条件并考虑脏数据。
- 除数防 0；必要时空值检查。

### 分层与客户端

- 客户端运行 .NET Framework 4.8，禁止直接引用中间件；中间件禁止引用客户端。提交时检查项目文件和 using。
- 中间件 `XXXManager` 已注入，用 `XServiceContainer.GetService()`；同一类型多次注入只保留最后一次，注入用 `TryAddXXX`。
- 禁止 `Delegate.BeginInvoke` / `EndInvoke`（.NET Core / 5+ 运行时报错）；多线程用 `Task.Run`。
- 路径用 `Path.Combine`，禁止硬编码 `\` 或 `/`；系统参数路径用 `/`。换行用 `Environment.NewLine`，禁止写死 `\r\n`。
- 远程方法尽量不用 `ref` / `out`。
- Remoting 注册的 Manager 是单例：不要设计实例字段；必须用则保证线程安全。

### 远程（gRPC / Dto）

- 需要远程的接口打 `[XService]`；不需要远程的不要打。接口与方法均禁止泛型。继承要谨慎，勿继承仅中间件内部使用的接口。
- Dto：`[Serializable]` + `[XContract]`；需序列化的属性打 `[XMember]`。只允许可读写自动属性或无逻辑的完整属性，禁止字段、禁止 getter 里写业务逻辑。
- 禁止循环引用、`DataTable` / `DataSet` / `DataRow`、`Tuple`、集合嵌套集合。集合仅 `List` / `Dictionary` / `HashSet` / `Array`。
- 形参/返回值声明类型必须与实际类型一致（禁止父类形参 + 子类实参）。
- 深拷贝禁止 BinaryFormatter / Protobuf 往返，必须自实现（`ICloneable` 等）。

### 边界

- 第三方组件引入/升级、框架代码（`xQuant.Common`、`SqlWhereHelper`、XPO 缓存等）须经架构组，见 [framework-guard.md](framework-guard.md)。
- 债券表、交易表、指令表禁止随意加字段或乱关联；加字段须架构组批准。
- 禁止为迁就界面把视图状态塞进核心对象（如 `XPOTCTrade.Selected`）。

## 源 Wiki

- [代码规范](http://172.19.6.53:7777/代码规范/)
- [代码评审清单](http://172.19.6.53:7777/代码规范/代码评审清单.html)
- [代码风格集合](http://172.19.6.53:7777/代码规范/代码风格集合.html)
- [开发杂谈](http://172.19.6.53:7777/代码规范/开发杂谈.html)
- [gRPC 远程方法规范](http://172.19.6.53:7777/代码规范/gRPC远程方法规范.html)
- [客户端信创后开发注意事项](http://172.19.6.53:7777/代码规范/客户端信创后开发注意事项.html)
- [框架代码维护清单](http://172.19.6.53:7777/代码规范/框架代码维护清单.html)
