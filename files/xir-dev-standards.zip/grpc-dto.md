# gRPC 远程方法与 Dto

源页面：[gRPC 远程方法规范](http://172.19.6.53:7777/代码规范/gRPC远程方法规范.html)

信创后客户端与中间件走 gRPC + Protobuf（原 Remoting + BinaryFormatter）。Dto 尽量简单，尽量只有自动属性。

## 远程接口

原 `XXXManager` 方法已提升到接口，客户端只通过接口交互。

- 需要远程的接口打 `[XService]`（会生成辅助代码）。不需要远程的接口不要打。
- 接口继承也会生成远程方法：不要继承仅中间件内部使用的接口。
- 接口、方法均禁止泛型。

## Dto 标记与成员

需要远程传输的对象统称 Dto。

必须同时打 `System.SerializableAttribute` 和 `xQuant.Framework.Common.XContractAttribute`：前者兼容 BinaryFormatter，后者让框架识别可能走 Protobuf。

```csharp
[Serializable]
[XContract]
public partial class XPOTCTrade {}
```

需要序列化的成员只能是可读写自动属性，或无逻辑的完整属性。禁止字段；禁止 getter/setter 里写业务逻辑。属性必须打 `XMemberAttribute`。

```csharp
[XMember]
public string Str { get; set; }

private int myVar;

[XMember]
public int MyProperty
{
    get => myVar;
    set => myVar = value;
}

private int myVar2;

// 错误：getter 含逻辑
[XMember]
public int MyProperty2
{
    get => myVar2 == 0 ? 1 : myVar2;
    set => myVar2 = value;
}
```

## 禁止循环引用

A 不能直接或间接再包含 A（含泛型参数）。

```csharp
[XContract]
[Serializable]
public class A
{
    /// <summary>A里不能有A</summary>
    [XMember]
    public A P1 { get; set; }

    /// <summary>泛型参数里也不能有A</summary>
    [XMember]
    public List<A> P3 { get; set; }

    /// <summary>A和B构成循环</summary>
    [XMember]
    public B P2 { get; set; }
}

[XContract]
[Serializable]
public class B
{
    [XMember]
    public A P1 { get; set; }

    [XMember]
    public C P2 { get; set; }
}

[XContract]
[Serializable]
public class C
{
    [XMember]
    public A P1 { get; set; }
}
```

## 构造函数与自定义序列化

- 后续远程方法的形参/返回值不允许自定义序列化过程（Protobuf 控不了）。`XPOTCTrade` 不要再用这套。
- 无参构造函数会被 Protobuf 调用（初始化逻辑会执行）；BinaryFormatter 不调用无参构造，结果可能不一致。

```csharp
// grpc 走这个构造函数
public XPOTCTrade() : base()
{
    this.InitInfo();
}

// remoting 走这个构造函数
public XPOTCTrade(SerializationInfo info, StreamingContext context)
    : base(info, context)
{
    // 自定义序列化逻辑
}
```

## 类型限制（新增方法；现有代码维护）

- 禁止 `DataSet` / `DataTable` / `DataRow` 及其强类型（也不许新增强类型）。
- 形参声明类型必须与实参实际类型一致；返回值声明类型必须与实际返回对象类型一致。禁止父类形参 + 子类实参（含 `object`、interface）。泛型参数同样（如 `List<object>` vs `List<interface>`）。框架为新增业务类型提供支持时可酌情兼容。
- 禁止 `Tuple`。
- 集合仅支持 `List`、`Dictionary`、`HashSet`、`Array`。**严格禁止集合嵌套集合**。框架无法给「集合的泛型参数仍是集合」打标签，序列化会失败。

## 集合嵌套：用 Dto 包装

原接口 `Dictionary<SecuInfoKey, List<BalanceBondInfo>>` 属于集合嵌套，信创后禁止传输。

方案 1：仍按 key 访问 value 时，把内层 List 包成类。

```csharp
public class BalanceBondInfos
{
    public List<BalanceBondInfo> Content { get; set; }

    public BalanceBondInfos(List<BalanceBondInfo> content)
    {
        Content = content;
    }
}

List<PriceMatchRecord> AutoPriceMatch(
    Dictionary<SecuInfoKey, BalanceBondInfos> dicSysInfos,
    Dictionary<SecuInfoKey, BalanceBondInfos> dicBalanceInfos,
    int balanceType);
```

方案 2：改成记录列表（调用代码会变多）。

```csharp
public class SecuBalanceBondRecord
{
    public SecuInfoKey Key { get; set; }
    public List<BalanceBondInfo> BalanceBondInfos { get; set; }

    public SecuBalanceBondRecord(SecuInfoKey key, List<BalanceBondInfo> balanceBondInfos)
    {
        Key = key;
        BalanceBondInfos = balanceBondInfos;
    }
}

List<PriceMatchRecord> AutoPriceMatch(
    List<SecuBalanceBondRecord> dicSysInfos,
    List<SecuBalanceBondRecord> dicBalanceInfos,
    int balanceType);
```

`List<List<PriceMatchRecord>>` 同理，包成 `List<PriceMatchRecords>`。

仍无法解决时联系技术组。

## 属性继承与 `[XMember]`

- 父类 `virtual` 属性：**不要**打 `[XMember]`；子类 `override` 后再打。
- 子类用同名属性隐藏父类属性时，另加序列化辅助属性。

```csharp
[XContract]
public class Parent
{
    public virtual int Prop1 { get; set; }
}

[XContract]
public class Child1 : Parent
{
    public int Prop1 { get; set; }

    [XMember]
    public int Prop1_Serialization
    {
        get => Prop1;
        set => Prop1 = value;
    }
}

[XContract]
public class Child2 : Parent
{
    [XMember]
    public override int Prop1 { get; set; }
}
```

## 深拷贝必须自实现

框架兼容 Protobuf 时无法自动深拷贝。禁止再用 BinaryFormatter 或 Protobuf 序列化往返做深拷贝（单独调序列化方法校验工具扫不到，可能漏类型导致失败；BinaryFormatter 也不再推荐）。

禁止：

```csharp
public XPCFETSMDQuote DeepClone()
{
#if NETFRAMEWORK
    using (var ms = new MemoryStream())
    {
        BinaryFormatter formatter = new BinaryFormatter();
        formatter.Serialize(ms, this);
        ms.Seek(0, SeekOrigin.Begin);
        return (XPCFETSMDQuote)formatter.Deserialize(ms);
    }
#elif NET
    return RuntimeTypeModelHelper.Default.Deserialize<XPCFETSMDQuote>(
        RuntimeTypeModelHelper.Default.Serialize(this));
#endif
}
```

自行实现：值类型直接赋值；不可变类型（如 `string`）可浅拷贝；可变引用类型递归深拷贝，嵌套类型实现 `ICloneable`。

```csharp
public class XPCFETSMDQuote : ICloneable
{
    public int QuoteId { get; set; }
    public List<Order> Orders { get; set; }
    public Person Trader { get; set; }

    public object Clone()
    {
        return new XPCFETSMDQuote
        {
            QuoteId = this.QuoteId,
            Trader = (Person)this.Trader.Clone(),
            Orders = this.Orders.ConvertAll(o => (Order)o.Clone()),
        };
    }
}
```

也可用表达式树缓存拷贝委托。远程方法尽量不用 `ref` / `out`。
