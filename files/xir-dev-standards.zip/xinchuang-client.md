# 客户端信创后开发

源页面：

- [客户端信创后开发注意事项](http://172.19.6.53:7777/代码规范/客户端信创后开发注意事项.html)
- [代码评审清单 · 信创后 / 客户端](http://172.19.6.53:7777/代码规范/代码评审清单.html)
- 图示示例：[客户端信创后开发规范示例](https://docs.qq.com/doc/DTWhIZ2RJck1nVGhO)

改 WinForms、客户端项目文件、路径/换行、依赖注入时读本文件。远程 Dto 见 [grpc-dto.md](grpc-dto.md)。

## 客户端与中间件隔离

中间件已完全信创化；客户端仍跑在 .NET Framework 4.8。

- 客户端代码禁止直接引用中间件；中间件禁止引用客户端。
- VS 可能无意引入引用，提交时检查项目文件和 using。
- 禁止使用 .NET 8 不支持的 API 或写法。
- 谨慎调用 Windows API；必须用时先评审信创兼容性。

## 依赖注入与 Manager

- 同一类型多次注入后，获取到的是最后一次；注入用 `TryAddXXX`。
- 中间件 `XXXManager` 已注入，用 `XServiceContainer.GetService()` 获取，不要自己 `new`。

## 路径与换行

- 禁止硬编码 `\` 或 `/`，拼接路径用 `Path.Combine`。系统参数中的路径统一用各平台都支持的 `/`。
- 禁止写死 `\r\n`，用 `Environment.NewLine`。解析文件时区分来源是 Windows 还是其它系统。

## 异步与析构

- 禁止 `Delegate.BeginInvoke` / `EndInvoke`（.NET Core / 5+ 编译过、运行时报错）。多线程和异步用 `Task.Run`。
- 避免析构函数；析构里抛异常会崩溃。必须用则 `try/catch`。

## WinForms 布局与资源

- 禁止完全限定类型名（尤其第三方类型）：类声明、对象创建、事件参数都不要写 `Namespace.Type`。
- DevExpress 同名类型同时存在于不同命名空间时，使用 `WinForm.Build.props` 里的全局别名（如 `GridPopupMenuShowingEventArgs`、`DevExpressPadding`），禁止在业务代码里加命名空间前缀消歧义。
- 颜色常量走 `ColorHelper`：`Color.Red` → `ColorHelper.Red`。
- 树或表格右键菜单必须用 `BarManager`，通过 `PopupMenuShowing` 显示。
- 新增界面的图片等资源不要写入 `Resources.resx`，直接用文件资源路径。
- 新增界面统一用 `LayoutControl`、`LayoutGroup`、`LayoutItem`。禁止新增 `PanelControl` 布局；禁止 `LayoutControl` 与 `PanelControl` 混嵌；禁止 `LayoutControl` 再嵌 `LayoutControl`。
- 能确定具体控件类型时不要用 `Control` 基类去改属性。

## 控件生命周期（评审清单 · 客户端）

- 新增控件加入 `Parent.Controls`。`RepositoryItem` 加到表格。动态移除要 `Dispose`。
- `ShowDialog` 用 `using`；模态关闭不会自动释放。
- XPO / 动态 `Timer` 注意解绑事件。
- 禁止在非 UI 线程弹窗或创建控件。非 UI 线程尽量 `BeginInvoke`；`Invoke` 前检查句柄与是否已释放。消息框委托到主线程（如 `XirHelper.ShowBoxInfoAsync`）。
- `BindAssistToGrid` 只绑一次。
- 动态控件初始化成对 `BeginUpdate` / `EndUpdate`（或 `SuspendLayout` / `ResumeLayout`）。
