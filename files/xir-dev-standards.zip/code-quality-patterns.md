# 代码风格与可执行杂谈

源页面：

- [代码风格集合](http://172.19.6.53:7777/代码规范/代码风格集合.html)
- [开发杂谈](http://172.19.6.53:7777/代码规范/开发杂谈.html)

写代码和评审时对照下列场景；不要把视图状态塞进核心对象，不要用字符串当 SQL / 业务主键。

## 场景一：注释与空集合

- 改代码必须同步改注释，否则误导后续阅读者。
- 尽量删除无用代码和注释。
- `null` 有含义，按场景使用。
- `IEnumerable` 无数据时返回空集合，不要返回 `null`：`new List<T>()`、`Array.Empty<T>()`、`Enumerable.Empty<T>()`。

## 场景二：不要复用变量

局部变量被反复赋值且含义不同，会降低可读性。栈上局部变量生命周期短，不要为这点开销牺牲可读性。

## 场景三：魔法值与索引

反例问题：

```csharp
string realParty = r.PARTY_ID.ToString() == "-1" ? PartyTag.TempPartyTag + r.PARTYNAMETEMPORITY.ToString() : r.PARTY_ID.ToString();
if (!string.IsNullOrEmpty(this._tableSource.Rows[j][0].ToString()) && FieldHelper.GetDecimal(this._tableSource.Rows[j][0]) == FieldHelper.GetDecimal(r.PRICE) && Convert.ToInt32(this._tableSource.Rows[j]["标位类型"]) == (r.IsDEALPRICETYPENull() ? (int)DealPriceType.DealPirceAvgSomeBiddings : r.DEALPRICETYPE))
{
}
```

- `-1` 表示什么必须说清（命名常量或注释）。
- 用 `row` 局部变量代替反复写 `this._tableSource.Rows[j]`。
- 列索引 `0` 有业务含义时不要用魔数；同一段里不要混用 `[j][0]` 和 `[j]["标位类型"]`。

## 场景四：抽象共同点，不要并列两个附件属性

不要：

```csharp
public IEnumerable<string> AttachFileList { get; set; }
public Dictionary<Stream, string> AttachmentStreamDict { get; set; } // 使用者不知道用哪个；string 含义不明
```

要：附件无论来自磁盘、网络还是内存，都用 `Stream` / `byte[]`，抽成一个类型。

```csharp
public IEnumerable<MailAttachment> AttachFileList { get; set; }

public class MailAttachment
{
    public string Name { get; }
    public byte[] Content { get; }
}
```

同一功能点不同场景先找共同点，再用继承或组合，而不是叠属性。

## 场景五：缩小作用域

`IsTradeSettleRow` 这类强业务、难复用的方法不要放在 `ClearingManager` 这类公共类里，方法名也要体现场景。

做法：为该场景单独建类，把辅助方法放进去；或做成本地函数，放在真正使用它的方法里。

## 场景六：复杂业务主键不要拼字符串

反例：

```csharp
string key = this.GetKeyValue(setDate, secu_ext_accid, biztypeKey, i_code, m_type, exe_market, quoteRepoOrddate, pledgBONDID);
string[] keyArray = kvp.Key.Split(',');
string bizTypeName = BizDict.IrSettleBizTypeDict.ContainsKey(keyArray[2]) ? BizDict.IrSettleBizTypeDict[keyArray[2]] : keyArray[2];
string instrumentCode = string.Format("金融工具代码:{0}", keyArray[3]);
```

问题：拼接耗时；以后加字段无法调顺序；`keyArray[2]` 含义不直观。

应定义 `class` 或 `struct` 并实现 `IEquatable`。字段过多只用 `class`（曾出现 struct 字段过多传参栈溢出）。

## 场景七：不要把业务拼成 SQL 字符串往下层传

禁止：

```csharp
public List<XPSecuPosition> GetPositionSecus(string aSecuAccid, List<InstrumentID> aInstrumentIds, string aSecuAccidExt)
{
    if (!string.IsNullOrEmpty(aSecuAccid))
    {
        aSecuAccid = string.Format(" AND A.ACCID='{0}'", aSecuAccid);
    }
    else
    {
        aSecuAccid = " AND 1=2";
    }

    if (!string.IsNullOrEmpty(aSecuAccidExt))
    {
        aSecuAccid += string.Format(" AND A.SECU_EXT_ACCID = '{0}'", aSecuAccidExt);
    }

    return TTRD_ACC_BALANCE_SECU.Query(aSecuAccid, aInstrumentIds);
}
```

参数保持业务含义，由 Dal 参数化拼 SQL。也不要用字符串表示返回结果。

## 核心对象 vs 边缘 UI

越靠近核心越谨慎。UI 勾选、展示列属于边缘代码，不要写进贯穿系统的核心对象。

- 禁止在 `XPOTCTrade` 上加 `Selected` 这类视图属性并在界面间共享。各界面勾选含义不同，各自处理。
- 仅为表格绑定、且按品种显示不同值的列：放到非绑定列 / ViewModel，不要给 `XPOTCIrSwap` 加视图属性（避免被误用）。

设计保持简单；为「也许会扩展」加的责任链、多余 DI、未封装进对象的转换层往往成为负担。

## 注释：写改动原因，不照搬 JIRA 标题

格式注意空格：

```csharp
// 2022-03-27 张三 P008XIR-77777 XIR产品-XXXXXXXXXXXXXX
```

日期、姓名、JIRA 号只为追溯。JIRA 号后必须说明这段代码改了什么、特殊场景为何这样处理。优秀代码本身要能表达；特殊分支必须交代背景和方案。

合格：

```csharp
// 2022-03-24 蔡彬彬 P008XIR-35765 转换的持仓日期必须等于当前清算日
// 考虑银行间清算时，会将基金市场拉进来清算，若基金市场的清算日期大于银行间的当前清算日期，那么不能直接转换持仓，必须从数据库读取
if (aOtherCondition && aCheckDate.CompareTo(preDate) == 0 && aPosition.BEG_DATE == this.CurSettleDate)
```

不合格（只抄了标题「东方证券-清算持仓变动量和核算基金过户数量与不一致的问题」）：

```csharp
// 2022-03-24 蔡彬彬 P008XIR-35765 东方证券-清算持仓变动量和核算基金过户数量与不一致的问题
if (aOtherCondition && aCheckDate.CompareTo(preDate) == 0 && aPosition.BEG_DATE == this.CurSettleDate)
```

## 其它可执行要点

- 不要随意关联表，特别是债券、交易。
- 删掉无用注释和被注释掉的代码；「以后可能再用」的代码大概率不会再用。
- `Dictionary<,>` 用 `TryGetValue`。
- 多次访问同一系统参数：存局部变量（`SystemParamConfiguration` 查找多为 O(n)）。循环、界面初始化同样适用。
- 性能敏感处把 `GridView.RowCount` 存局部变量。
- 与服务端交互的方法尽量不用 `ref` / `out`。
- FPML：不要在客户端取完要素就 `BuildFPML` 再把整段 XML 传到服务端（接口测试传一长串 XML 不现实）。把生成 FPML 的要素封进对象，反序列化时再 `BuildFPML`。
- 递归考虑脏数据。
- 实现了 `IDisposable` 的类型用 `using`；成员可释放则类型也实现 `IDisposable`。`ShowDialog` 窗口必须释放。
- 界面表格选择列可用 `HashSet<>`。
- 客户一天只用一两次的功能，不要为了缓存而缓存。
