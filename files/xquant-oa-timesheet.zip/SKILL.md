---
name: xquant-oa-timesheet
description: Logs into Hengtai/xQuant OA (oa.xquant.com), opens 工时填报流程, fills the monthly timesheet, and saves without submitting. Detects Cursor vs Codex and uses that product's built-in browser. Use when the user asks to 填工时, 工时填报, 衡泰 OA 工时, xQuant OA timesheet, or provides OA credentials to file hours.
---

# xQuant OA 工时填报

登录衡泰 OA → 打开工时填报流程 → 按法定工作日加行并填表 → **只保存不提交**。

账号密码由用户当次提供。禁止把密码写入本 skill 或本地文件。

## 环境：先认 Cursor / Codex，再用内置浏览器

用户确认账号密码之后、打开登录页之前，必须判定环境并选用对应内置浏览器。细则见 [browsers.md](browsers.md)。

1. **Cursor**：有 `browser_navigate` / `browser_snapshot` / `browser_cdp`（`cursor-ide-browser`）→ 用 Cursor 内置浏览器。
2. **Codex**：有 Browser 插件 / `mcp__node_repl__js` / `agent.browsers` → 按 Codex `control-in-app-browser` 接内置浏览器（`iab` 或 `getForUrl("https://oa.xquant.com/")`）。
3. 都没有：停止，说明当前没有内置浏览器。

回复里写一句 `当前环境：Cursor` 或 `当前环境：Codex`。后面步骤的「点、填、截图」都走该环境的 API，不要混用另一边的工具名。

## 默认填报内容

用户未另给时使用：

| 列 | 值 |
|---|---|
| 工时类型 | 研发 |
| 工时细分 | 衡泰利率资产业务管理系统 V1.3 |
| 工作内容 | BevisTest |
| 工时时长 | `8 - 请假时长`（小于 0 则 0） |
| 月份 | 今天所在自然月 |
| 结束动作 | 点「保存」，禁止点「提交」 |

## 0. 先要账号密码并回显核对

**每次使用本 skill，第一步必须做这件事，未完成前不得打开登录页。**

1. 若用户还没给账号或密码：立刻提醒「请提供 OA 账号和密码」，然后停止等待。
2. 用户给出后，在回复里**原样输出**（不要省略、不要改写、不要丢掉末尾标点）：

```
本次将使用的登录信息：
- 账号：{用户给的账号}
- 密码：{用户给的密码}
请核对是否正确。正确就回复「对」或「继续」，不对就重新发账号密码。
```

3. 用户确认正确后，才进入登录。密码按原文使用（含末尾 `.` 等字符）。

## 进度清单

```
- [ ] 提醒并拿到账号密码
- [ ] 回显账号密码，等用户核对确认
- [ ] 判定 Cursor 或 Codex，接上对应内置浏览器
- [ ] 登录（先刷新验证码再填）
- [ ] 进入 工时管理 → 工时填报流程
- [ ] 按当月法定工作日加行
- [ ] 填日期、工时类型、工时细分、工作内容、工时时长
- [ ] 只保存，确认变为「流程-处理」
```

## 1. 登录

1. 用当前环境的内置浏览器打开 `https://oa.xquant.com/`（不必用户先开页面）。
2. 表单：`#loginid`、`#userpassword`、`#validatecode`。
3. **每次点登录前**点击 `.e9login-form-vc-img img` 刷新验证码，再截图识别。
4. 填账号、密码、验证码。密码必须与用户给出的字符串完全一致（含末尾 `.`）。Cursor 用 `browser_fill`；Codex 用其 browser `documentation()` 里的输入 API。
5. 提交前用页面 JS 核对：`loginid`、密码长度/末位、验证码。
6. 点「登 录」。成功标志：标题为「衡泰技术个人门户」。
7. 验证码看错或仍停在登录页：刷新验证码重试，最多 4 次。仍失败则停，让用户接管。

不要勾「记住密码」。登录信息只在对话里回显给用户核对，不要写入 skill 或磁盘文件。

## 2. 进入工时填报流程

1. 用坐标点击顶部可见菜单「工时管理」（隐藏 `menuitem` 点不了）。
2. 下拉出现后点「工时填报流程」。
3. 等到「流程-创建 - 工时填报流程」。表单在 `#mainFrame` iframe 内。

表单操作一律对 `document.getElementById('mainFrame').contentDocument` / `contentWindow.WfForm`。Cursor 的 snapshot ref 进不了 iframe，用 CDP `Runtime.evaluate`；Codex 在选中的 tab 里 evaluate。浏览框弹层在**父页面**。

## 3. 法定工作日

查当年「国务院办公厅关于 N 年部分节假日安排的通知」，计算填报月工作日：

- 周一至周五
- 减去当月法定放假日
- 加上当月调休上班日（例如 2026-09-20 周日上班，2026-09-25～27 中秋放假）

行数 = 工作日天数。默认已有 1 行时，再点加号 `工作日数 - 1` 次。

加号：iframe 内可见的 `i.icon-coms-Add-to-hot.detailBtn`（`#addbutton0`）。以 `#oTable0 tr.detail_data_row` 计数。

## 4. 填表（WfForm）

`const WfForm = iframe.contentWindow.WfForm`  
`const indexes = WfForm.getDetailAllRowIndexStr('detail_1').split(',')`

字段与写法见 [fields.md](fields.md)。

顺序必须是：

1. **日期** `field13666_*`：每个工作日一个 `YYYY-MM-DD`。
2. **工时类型** `field13667_*`：研发 = `'4'`。
3. **工时细分**：选「研发」后，可见列是技术产品 `field13672`（`data-fieldname="yf"`），**不是**项目 `xm`。
   - 在第一行点 `yf` 单元格的放大镜。
   - 父页面弹层标题为「技术产品名称」。
   - 搜索目标产品名，点中匹配行（对 `tr.ant-table-row` 的 `td` 派发 click）。
   - 用 `getFieldValue` / `getBrowserShowName` 取出 id 与名称，再 `changeFieldValue` 写到其余行。
   - 禁止把名称当纯文本写入 input。
4. **工作内容** `field13673_*`：`BevisTest`。
5. **工时时长** `field13674_*`：读同行列假 `field13745_*`（`qjscxs`），`工时时长 = 8 - 请假时长`。

填完核对每一行：日期、类型显示「研发」、细分名称、内容、时长。合计时长应等于各行时长之和。

## 5. 保存

点 iframe 内可见按钮「保 存」，**不要**点「提 交」。

成功：标题变为「流程-处理 - 工时填报流程」，URL 出现 `requestid`。数据仍在表上。

## 失败处理

- 登录报密码错误：先核对密码是否漏了末尾字符；再刷新验证码（验证码错也可能报密码错误）。
- 工时细分搜不到：确认弹层是「技术产品名称」不是「项目」；工时类型必须已是研发。
- iframe 按钮点不到：在 `#mainFrame` 里对元素 `click()`。Cursor 不要用父页面 snapshot ref。
- Codex 报 in-app browser unavailable：见 [browsers.md](browsers.md)，不要改走 Cursor 工具名。
