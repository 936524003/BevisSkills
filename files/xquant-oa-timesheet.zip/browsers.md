# 浏览器环境：Cursor 或 Codex

先判定当前会话，再用对应内置浏览器。业务步骤（登录、填表、保存）见 [SKILL.md](SKILL.md)，字段见 [fields.md](fields.md)。

## 判定（按顺序，命中即停）

1. **Cursor**：工具里有 `browser_navigate`、`browser_snapshot`、`browser_click`、`browser_fill`、`browser_cdp`，或命名空间 `cursor-ide-browser`。
2. **Codex**：已加载 `control-in-app-browser` / Browser 插件，或有 `mcp__node_repl__js`（Node REPL `js`），可 `import` `browser-client.mjs` 并调用 `agent.browsers`。
3. 两者都没有：停止，说明当前环境没有内置浏览器，不要用 Playwright CLI 或乱点桌面当默认方案。

在回复里用一句话报当前环境：`当前环境：Cursor` 或 `当前环境：Codex`。

## Cursor：cursor-ide-browser

- 先 `browser_tabs` list，再 `browser_navigate` 打开 `https://oa.xquant.com/`。
- 操作前 `browser_lock`，全部完成后 `browser_unlock`。
- 登录页：`browser_fill` / `browser_click`；验证码截 `.e9login-form-vc-img img`。
- 进 iframe 后 snapshot ref 无效。用 `browser_cdp` → `Runtime.evaluate` 访问 `#mainFrame` 的 `contentDocument` / `WfForm`。
- 顶部「工时管理」用可见坐标点；技术产品弹层在**父页面**。

## Codex：in-app Browser（优先）

不要用 Cursor 的 `browser_*` 工具名。按会话里的 `control-in-app-browser` skill 初始化，摘要如下。

1. 用 Node REPL `js`（常见 id：`mcp__node_repl__js`）加载插件根目录的 `scripts/browser-client.mjs`（绝对路径）。找不到该文件就停，报 Browser 插件缺失。
2. 只初始化一次：

```js
if (globalThis.agent?.browsers == null) {
  const { setupBrowserRuntime } = await import("<plugin root>/scripts/browser-client.mjs");
  await setupBrowserRuntime({ globals: globalThis });
}
```

3. 选浏览器：用户没点名时用目标 URL，优先内置浏览器：

```js
if (globalThis.browser == null) {
  globalThis.browser = await agent.browsers.getForUrl("https://oa.xquant.com/");
  nodeRepl.write(await browser.documentation());
}
```

若用户明确要内置浏览器：`globalThis.iab = await agent.browsers.get("iab")`，并完整阅读 `iab.documentation()`。

4. **必须先读完** `documentation()` 再操作。之后只用文档里的 API（含 `tab.playwright`、截图、evaluate）。不要改用外部 Playwright MCP。
5. 把 OA 步骤映射到该 API：打开 OA → 截验证码图并识别 → 填 `#loginid` / `#userpassword` / `#validatecode`（每次登录前点验证码图刷新）→ 点登录 → 点工时管理/工时填报流程 → 在 `#mainFrame` 里跑 `WfForm` JS → 点保存。
6. Codex 纯 CLI 且 `iab` 不可用时：不要假装成功。改试 `agent.browsers.getDefault()`；仍失败则告诉用户需要 Codex 桌面内置浏览器或已连接的 Chrome 扩展（Settings → Computer use）。

## 对照

| 意图 | Cursor | Codex |
|---|---|---|
| 打开 URL | `browser_navigate` | browser-client 选中的 tab 导航 |
| 点击 | `browser_click` / 坐标 | 文档中的 click / playwright |
| 输入 | `browser_fill` | 文档中的 type/fill |
| 截图识验证码 | `browser_take_screenshot` | 文档中的 screenshot |
| iframe / WfForm | `browser_cdp` Runtime.evaluate | tab 内 evaluate，目标 `#mainFrame` |
| 锁标签 | `browser_lock` / unlock | 按 Codex 文档；无则忽略 |
