# 工时填报表单字段

表单在 `#mainFrame`。用 `WfForm.changeFieldValue(fieldId, {value, specialobj})`。

## 明细字段

| 列（界面） | fieldname | 字段 ID | 控件 | 备注 |
|---|---|---|---|---|
| 日期 | `rq` | `field13666_{row}` | 日期 | `YYYY-MM-DD` |
| 工时类型 | `gslx` | `field13667_{row}` | 下拉 | 见下方选项 |
| 项目 | `xm` | `field13668_{row}` | 浏览 `browser.xm1` | 类型=项目时显示；研发时 `display:none` |
| 技术产品名称 | `yf` | `field13672_{row}` | 浏览 `browser.jscpmc` | **研发时的工时细分** |
| 产品模块 | `cpmk` | `field18253_{row}` | 浏览 `browser.cpmk` | 默认不填 |
| 工作内容 | `gznr` | `field13673_{row}` | 文本域 | |
| 工时时长 | `gssc` | `field13674_{row}` | 数字 | `8 - 请假时长` |
| 请假时长（小时） | `qjscxs` | `field13745_{row}` | 只读/联动 | 按行读取 |

工时类型选项：`0` 项目，`1` 项目维保期运维，`2` 维护合同，`3` 部门，`4` 研发，`5` POC。

## 行索引

```js
const WfForm = document.getElementById('mainFrame').contentWindow.WfForm;
const indexes = WfForm.getDetailAllRowIndexStr('detail_1').split(',');
```

## 加行

```js
const doc = document.getElementById('mainFrame').contentDocument;
const btn = [...doc.querySelectorAll('i.icon-coms-Add-to-hot.detailBtn')]
  .find(el => el.getBoundingClientRect().width > 0);
btn.click();
// 行数：doc.querySelectorAll('#oTable0 tr.detail_data_row').length
```

## 浏览框选技术产品

1. 点第一行 `[data-fieldname="yf"] button`。
2. 弹层在**父 document**，标题「技术产品名称」。
3. 搜索产品名，点结果行选中。
4. 复制到其余行：

```js
const id = WfForm.getFieldValue('field13672_0');
const name = WfForm.getBrowserShowName('field13672_0');
const obj = WfForm.getFieldValueObj('field13672_0');
indexes.forEach((idx) => {
  if (idx === '0') return;
  WfForm.changeFieldValue('field13672_' + idx, {
    value: id,
    specialobj: obj.specialobj || [{ id, name }]
  });
});
```

## 保存

iframe 内 `button` 文本去掉空格等于 `保存` 且 `getBoundingClientRect().width > 0`。不要点 `提交`。
